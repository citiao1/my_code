
////////////////////////////PS2引脚接线/////////////////////
//   PS2丝印标识(共9个引脚)-----------------ArduinoUNO主板引脚
// (绿灯到红灯方向第4个)GND-----------------GND
// (绿灯到红灯方向第5个)VDD-----------------5V
// (绿灯到红灯方向第1个) DI-----------------8
// (绿灯到红灯方向第2个) DO-----------------7
// (绿灯到红灯方向第6个) CS-----------------6
// (绿灯到红灯方向第7个)CLK-----------------5
//   PS2丝印标识(共9个引脚)-----------------ArduinoUNO主板引脚

#include <PS2X_lib.h> //PS2X库函数
PS2X ps2x; //创建一个PS2X对象

//////////PS2引脚//////////////////一共4个信号引脚
#define PS2_DAT        8  //DI
#define PS2_CMD        7  //DO
#define PS2_SEL        6  //CS
#define PS2_CLK        5  //CLK

unsigned char PS2_LX,PS2_LY,PS2_RX,PS2_RY;  //左摇杆X轴坐标，左摇杆Y轴坐标，右摇杆X轴坐标，右摇杆Y轴坐标
                                            //原点坐标(0, 0)在左上角
                                            
//void (* resetFunc) (void) = 0;// Reset func

/***********函数功能：初始化 相当于STM32里面的Main函数 作者：平衡小车之家************/
void setup()   
{
  char error;
  Serial.begin(9600);        //开启串口  
  Serial.println("PS2初始化..."); 
  error=ps2x.config_gamepad(PS2_CLK, PS2_CMD, PS2_SEL, PS2_DAT, false, false);//初始化ps2，如果初始化成功返回byte值0
  if(!error)Serial.println("PS2初始化成功！");
  else Serial.println("PS2初始化失败！");
}

/******函数功能：主循环程序体*******/
void loop()
{
    ps2x.read_gamepad(false, 0); //read controller and set large motor to spin at 'vibrate' speed
    PS2_LX=ps2x.Analog(PSS_LX);  //读取拍摄ps2左摇杆X坐标并赋值给PS2_LX
    PS2_LY=ps2x.Analog(PSS_LY);  //读取拍摄ps2左摇杆Y坐标并赋值给PS2_LY
    PS2_RX=ps2x.Analog(PSS_RX);  //读取拍摄ps2右摇杆X坐标并赋值给PS2_RX
    PS2_RY=ps2x.Analog(PSS_RY);  //读取拍摄ps2右摇杆Y坐标并赋值给PS2_RY

    //串口发送左右摇杆坐标状态
    Serial.print("PS2_LX:");
    Serial.print(PS2_LX);
    Serial.print("   PS2_LY:");
    Serial.print(PS2_LY);
    Serial.print("   PS2_RX:");
    Serial.print(PS2_RX);
    Serial.print("   PS2_RY:");
    Serial.print(PS2_RY);

    //ps2x.Button()是ps2按键被按住的触发函数，返回boolean值
    Serial.print("   Key State:");
    if(ps2x.Button(PSB_TRIANGLE))          Serial.println("PSB_TRIANGLE being pressed");
//    else if(ps2x.Button(PSB_CROSS))        Serial.println("PSB_CROSS being pressed");
//    else if(ps2x.Button(PSB_CIRCLE))       Serial.println("PSB_CIRC being pressed");
//    else if(ps2x.Button(PSB_SQUARE))       Serial.println("PSB_SQUARE being pressed");
//    else if(ps2x.Button(PSB_PAD_UP))       Serial.println("PSB_PAD_UP being pressed");
//    else if(ps2x.Button(PSB_PAD_DOWN))     Serial.println("PSB_PAD_DOWN being pressed");
//    else if(ps2x.Button(PSB_PAD_RIGHT))    Serial.println("PSB_PAD_RIGHT being pressed");
//    else if(ps2x.Button(PSB_PAD_LEFT))     Serial.println("PSB_PAD_LEFT being pressed");
//    else if(ps2x.Button(PSB_R1))           Serial.println("PSB_R1 being pressed");
//    else if(ps2x.Button(PSB_R2))           Serial.println("PSB_R2");
//    else if(ps2x.Button(PSB_SELECT))       Serial.println("PSB_SELECT being pressed");
//    else if(ps2x.Button(PSB_START))        Serial.println("PSB_START being pressed");
//    else if(ps2x.Button(PSB_L1))           Serial.println("PSB_L1 being pressed");
//    else if (ps2x.Button(PSB_L2))          Serial.println("PSB_L2 being pressed");
//    else Serial.println(" All empty");

    //ps2x.NewButtonState()是ps2按键被按下或者松开的触发函数，返回boolean值
    if(ps2x.NewButtonState(PSB_CROSS))Serial.println("PSB_CROSS have been pressed or released");


    //ps2x.ButtonPressed()是ps2按键被按下的触发函数，返回boolean值
    if(ps2x.ButtonPressed(PSB_CIRCLE)) Serial.println("PSB_CIRCLE have been pressed");


    //ps2x.ButtonReleased()是ps2按键被松开的触发函数，返回boolean值
    if(ps2x.ButtonReleased(PSB_SQUARE)) Serial.println("PSB_SQUARE have been released");

     Serial.println();
}
