#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
project_dir="$(cd "$script_dir/.." && pwd)"
venv_dir="${MECANUM_CONSOLE_VENV:-$HOME/.venvs/mecanum-console}"
serial_port="${SERIAL_PORT:-/dev/ttyS5}"
serial_baud="${SERIAL_BAUD:-115200}"
listen_host="${CONSOLE_HOST:-0.0.0.0}"
http_port="${HTTP_PORT:-8088}"
ws_port="${WS_PORT:-8766}"

if [[ ! -x "$venv_dir/bin/python" ]]; then
  echo "Python environment not found: $venv_dir"
  echo "Run first: bash $script_dir/setup.sh"
  exit 1
fi

cleanup() {
  trap - EXIT INT TERM
  [[ -n "${http_pid:-}" ]] && kill "$http_pid" 2>/dev/null || true
  [[ -n "${bridge_pid:-}" ]] && kill "$bridge_pid" 2>/dev/null || true
  wait "${http_pid:-}" "${bridge_pid:-}" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

"$venv_dir/bin/python" -m http.server "$http_port" \
  --bind "$listen_host" --directory "$project_dir" &
http_pid=$!

"$venv_dir/bin/python" "$project_dir/bridge/motor_vofa_bridge.py" \
  --transport serial \
  --port "$serial_port" \
  --baud "$serial_baud" \
  --ws-host "$listen_host" \
  --ws-port "$ws_port" &
bridge_pid=$!

echo "Web console: http://<orange-pi-ip>:$http_port"
echo "UART bridge: $serial_port @ $serial_baud"
echo "Press Ctrl+C to stop both services."

wait -n "$http_pid" "$bridge_pid"
