#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
project_dir="$(cd "$script_dir/.." && pwd)"
venv_dir="${MECANUM_CONSOLE_VENV:-$HOME/.venvs/mecanum-console}"
serial_port="${SERIAL_PORT:-/dev/ttyS5}"
serial_baud="${SERIAL_BAUD:-115200}"
listen_host="${CONSOLE_HOST:-0.0.0.0}"
http_port="${HTTP_PORT:-8088}"
ws_port="${WS_PORT:-8766}"
camera_device="${CAMERA_DEVICE:-/dev/video1}"
camera_host="${CAMERA_HOST:-0.0.0.0}"
camera_port="${CAMERA_PORT:-8081}"
camera_resolution="${CAMERA_RESOLUTION:-320x240}"
camera_fps="${CAMERA_FPS:-10}"
camera_quality="${CAMERA_QUALITY:-45}"
camera_buffers="${CAMERA_BUFFERS:-2}"
camera_workers="${CAMERA_WORKERS:-1}"

if [[ ! -x "$venv_dir/bin/python" ]]; then
  echo "Python environment not found: $venv_dir"
  echo "Run first: bash $script_dir/setup.sh"
  exit 1
fi

if ! command -v ustreamer >/dev/null 2>&1; then
  echo "uStreamer not found. Install it first: sudo apt install -y ustreamer"
  exit 1
fi

cleanup() {
  trap - EXIT INT TERM
  [[ -n "${http_pid:-}" ]] && kill "$http_pid" 2>/dev/null || true
  [[ -n "${bridge_pid:-}" ]] && kill "$bridge_pid" 2>/dev/null || true
  [[ -n "${camera_pid:-}" ]] && kill "$camera_pid" 2>/dev/null || true
  wait "${http_pid:-}" "${bridge_pid:-}" "${camera_pid:-}" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

"$venv_dir/bin/python" -m http.server "$http_port" \
  --bind "$listen_host" --directory "$project_dir" &
http_pid=$!

"$venv_dir/bin/python" "$project_dir/bridge/motor_vofa_bridge.py" \
  --transport serial \
  --port "$serial_port" \
  --baud "$serial_baud" \
  --ws-host "$listen_host" \
  --ws-port "$ws_port" &
bridge_pid=$!

ustreamer \
  --device "$camera_device" \
  --host "$camera_host" \
  --port "$camera_port" \
  --resolution "$camera_resolution" \
  --format JPEG \
  --desired-fps "$camera_fps" \
  --quality "$camera_quality" \
  --buffers "$camera_buffers" \
  --workers "$camera_workers" &
camera_pid=$!

echo "Web console: http://<orange-pi-ip>:$http_port"
echo "UART bridge: $serial_port @ $serial_baud"
echo "Camera stream: http://<orange-pi-ip>:$camera_port/stream"
echo "Press Ctrl+C to stop all services."

wait -n "$http_pid" "$bridge_pid" "$camera_pid"
