# C30D 麦轮底盘控制台

配套固件：`mecanum_motor_test`。

## 启动

双击 `启动上位机.bat`：

1. 选择 `1` 使用 USB 串口桥接，或选择 `2` 使用 BLE 桥接。
2. 启动器自动准备运行环境、启动网页和桥接程序并打开浏览器。
3. 网页保持“本地桥接 + VOFA”，点击“连接”。

网页地址：`http://127.0.0.1:8088`

## Orange Pi Zero 3 局域网串口桥接

将整个 `mecanum-motor-console` 目录传到香橙派后，先安装 Python 虚拟环境支持并执行一次初始化：

```bash
sudo apt update
sudo apt install -y python3-venv
cd ~/mecanum-motor-console
bash orange-pi/setup.sh
```

默认使用 Zero 3 UART5（`/dev/ttyS5`）和 `115200, 8N1`：

```bash
cd ~/mecanum-motor-console
bash orange-pi/start.sh
```

同一局域网中的电脑或手机访问 `http://<香橙派IP>:8088`，选择“本地桥接 + VOFA”并点击连接。可通过 `SERIAL_PORT`、`SERIAL_BAUD`、`HTTP_PORT` 和 `WS_PORT` 环境变量覆盖默认值。

## 控制协议

```text
W / A / S / D / Q / E
DRV,30,15,10
STOP
ZERO
SPEED,30
PIDON,1
PIDRESET
YAWON,1
YAWRESET
HEADON,1
HEADSTEP,45
HEADHOLD
HEADRESET
GYROCAL
YAWZERO
A+ / A- / B+ / B- / C+ / C- / D+ / D-
STATUS
```

`SPEED` 允许范围为 5-120。W/S/A/D 时表示轮速 RPM，Q/E 时表示目标角速度 °/s。MPU6050 和四轮速度环共用 20 ms 控制周期；角速度环使用位置式 PI，输出旋转轮速分量，四轮继续使用增量式 PI。单轮点动仍使用 15% 开环 PWM。运动命令需要约每 100 ms 刷新一次，固件超过 300 ms 未收到刷新会自动停车。

`DRV,forward_rpm,left_rpm,yaw_dps` 支持三项同时输入；正 `forward` 前进，正 `left` 左移，正 `yaw` 左旋。三项绝对值均不得超过当前 `SPEED`，`DRV,0,0,0` 等价于停车。非零 `yaw` 由角速度内环直接控制；`yaw=0` 时航向角外环锁定当前航向，并把修正角速度交给角速度内环。主动旋转结束后会捕获新的当前航向，不会自动转回旋转前的角度。

电脑键盘支持同时按下多个 `W/A/S/D/Q/E`，网页会按当前速度档位每 100 ms 发送组合 `DRV`；例如 `W+A+Q` 表示左前平移并左旋。松开部分按键会立即更新剩余分量，全部松开立即发送 `STOP`。页面上的单个方向按钮继续使用原有单方向命令。

双摇杆复用同一条 `DRV` 协议。左摇杆控制前后和左右平移，右摇杆横轴控制旋转；两个手指可以同时操作。摇杆带 10% 中心死区，松开一侧只清除对应分量，两个摇杆都松开、页面切到后台、连接断开或按下 STOP 时立即停车。

## 手机直接连接 BLE

Android 手机使用 Chrome 或 Edge 打开 HTTPS 版本的控制台，不需要电脑桥接程序。首次打开 `?mobile=1` 地址后选择“添加到主屏幕”；PWA 安装完成后会缓存网页，之后可以离线启动并直接连接 BT05。手机模式只保留“浏览器直连 BLE”，点击连接后在系统设备列表中选择提供 `FFE0/FFE1` 服务的模块。

Web Bluetooth 要求 HTTPS 或本机 `localhost`，所以手机不能直接使用电脑局域网的普通 `http://电脑IP:8088`，也不建议直接打开复制到手机的 HTML 文件。发布时将整个 `mecanum-motor-console` 目录放到 GitHub Pages、Gitee Pages 或其他 HTTPS 静态站点，入口使用：

```text
https://你的域名/路径/?mobile=1
```

首次安装需要访问该 HTTPS 地址；安装后不再需要电脑或 BAT。BLE 连接需要用户手势授权，断联后必须重新点击连接，网页不会自动恢复上一次运动。iPhone 的 Safari/Chrome 不提供标准 Web Bluetooth；iPhone 需要后续封装原生 App，当前 PWA 方案面向 Android。

遥测格式：

```text
TEL,time_ms,mode,enable,
encA,encB,encC,encD,
pwmA,pwmB,pwmC,pwmD,
rpmA,rpmB,rpmC,rpmD,
targetA,targetB,targetC,targetD,
battery_mV,kp_x1000,ki_x1000,kd_x1000,output_limit,integral_limit,pid_enabled,
gyro_connected,gyro_ready,gyro_calibrating,gyro_raw_mdps,gyro_filtered_mdps,yaw_mdeg,
yaw_target_mdps,yaw_output_mrpm,yaw_kp_x1000,yaw_ki_x1000,yaw_kff_x1000,yaw_enabled
heading_target_mdeg,heading_feedback_mdeg,heading_error_mdeg,heading_output_mdps,
heading_kp_x1000,heading_kd_x1000,heading_max_rate_mdps,heading_enabled,heading_holding
```

车轮编号：A 右后、B 左后、C 右前、D 左前。

四轮目标符号：

```text
W  + + + +    S  - - - -
A  - + + -    D  + - - +
Q  + - + -    E  - + - +
```

速度 PID 使用增量式公式，固件已固定为 `Kp=0.8`、`Ki=0.1`、`Kd=0`，输出限幅固定为 60%。`Ki` 是 20 ms 采样周期下的离散增益。网页不提供速度环参数调节 UI；旧的 `PID` 和 `PIDLIM` 命令会返回 `PID_FIXED`。

角速度 PI 已固定为 `Kp=0.15`、`Ki=2.5`，不使用前馈。`YAWPID` 命令会返回 `YAWPID_FIXED`，网页不再提供参数调节。上电后 MPU6050 先预热并在静止状态采集 200 个样本；OLED 上 `G:C/R/E` 分别表示校准、就绪、故障。校准未完成或传感器离线时，Q/E 命令会被拒绝。

航向角外环采用位置式 PD，参数已固定为 `Kp=5.0`、`Kd=1.25`，最大修正角速度 `80 °/s`。`HEADPID` 命令会返回 `HEADPID_FIXED`，网页不再提供航向参数调节。`HEADSTEP,delta_deg` 在车辆正以 `DRV,...,0` 行驶时，将目标航向相对当前航向改变 `-170°` 到 `+170°`。`HEADHOLD` 首次执行时把当前朝向清零并锁定为 `0°`，后续重复执行只刷新通信看门狗，必须用 `STOP` 退出。

波形自动测试包含“折线路径”“角速度正反阶跃”和“0°抗扰保持”。抗扰测试只需设置保持时间：开始后等待页面显示 `HOLD 0°`，再用手缓慢转动车体并松手，测试期间不要抬起或推动底盘。页面不会根据误差自动判定抗扰效果；到时、中止、遥测异常或控制环失效都会停车，且测试可再次启动。

## 安全

网页在硬件在线、PD3 为高、遥测未超时且轮速 PID 已启用时允许发送整车运动命令。Q/E 还要求 MPU6050 已就绪且角速度环已启用。固件仍是最终安全层。
