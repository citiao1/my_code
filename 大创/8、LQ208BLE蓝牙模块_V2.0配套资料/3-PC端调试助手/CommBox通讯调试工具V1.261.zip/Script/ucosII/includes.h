/*
*********************************************************************************************************
*                                                uC/OS-II
*                                          The Real-Time Kernel
*
*                              (c) Copyright 1992-2004, Micrium, Weston, FL
*                                           All Rights Reserved
*
*                                           MASTER INCLUDE FILE
*********************************************************************************************************
*/

#include    <stdio.h>
#include    <string.h>
#include    <ctype.h>
#include    <stdlib.h>

#include    <..\\script\\ucosii\\app_cfg.h>
#include    <..\\script\\ucosii\\ucos_ii.h>

#if OS_VIEW_MODULE
#include    <os_viewc.h>
#include    <os_view.h>
#endif
