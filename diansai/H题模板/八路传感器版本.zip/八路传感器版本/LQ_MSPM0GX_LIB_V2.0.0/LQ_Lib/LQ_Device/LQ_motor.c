/*******************************************************************************
 * @file                LQ_motor.c
 * @brief               本文件是 LQ_MSPM0GX_LIB 驱动库源文件之一
 * @copyright           版权所有 (C) 2025-2026 龙邱科技科技有限公司
 * @website             http://www.lqist.cn
 * @taobao              http://longqiu.taobao.com
 *
 * @description         龙邱科技 MSPM0G3507 开发板驱动库
 *
 * 硬件运行环境:
 *   - 使用编译器 : Keil5
 *   - 目标芯片 : MSPM0G3507
 *   - 外部晶振 : 16.000MHz
 *   - 系统时钟 : 80MHz
 *
 * 本文件遵循GPL-3.0开源协议发布,宗旨为 MSPM0G3507 芯片嵌入式系统开发者提供一套可在 MSPM0G3507 相关应用层的参考实例
 * 商业用途请联系上方使用授权,使用前请联系上方软件著作权
 *
 * GPL-3.0 许可证条款摘要:
 * 1. 任何人可使用、修改、分发本软件
 * 2. 分发修改后的版本时,必须采用相同开源许可证
 * 3. 必须保留原始版权信息和许可证信息
 * 4. 不提供任何的担保使用方法分别负责
 * 5. 完整协议的副本见项目目录 LICENSE 文件
 *
 * @author              LQ_012
 * @email               chiusir@163.com
 * @version             V2.0.0
 * @update              2026年4月24日
 *******************************************************************************/
#include "LQ_motor.h"

/* 模块内部:保存左右电机上一次的方向(+1/-1/0),用于换向时的死区保护
 * 防止 H 桥上下臂直通造成短路
 */
static int8_t s_left_previous_direction  = 0;
static int8_t s_right_previous_direction = 0;

/*************************************************************************
 * @name     LQ_Motor_InitBridge
 *
 * @brief    初始化一个 H 桥占用的两个 PWM 通道(同一定时器)
 * @param    timer    H 桥占用的定时器枚举
 * @param    in1      H 桥 IN1 端对应的 PWM 通道(同时含引脚信息)
 * @param    in2      H 桥 IN2 端对应的 PWM 通道
 * @note     流程:
 *           1. 调用 LQ_PWM_CalcOptimal 根据目标频率计算最优分频/预分频/周期
 *           2. 初始化定时器为边沿对齐 PWM 模式,先不启动
 *           3. 使能两个 PWM 通道(IO 复用)
 *           4. 设置初始比较值为 0,确保上电不误转
 *           5. 启动定时器开始输出
 *************************************************************************/
static void LQ_Motor_InitBridge(LQEnum_Timer_t timer,
                                LQEnum_PWM_Pin_t in1, LQEnum_PWM_Pin_t in2,
                                uint32_t target_freq)
{
    PWM_ConfigTypeDef cfg = LQ_PWM_CalcOptimal(timer, target_freq);
    LQConfig_PWM_InitTypeDef_t pwm_init = {
        .DivideRatio = (DL_TIMER_CLOCK_DIVIDE)(cfg.DivideRatio - 1U),
        .Prescaler   = cfg.Prescaler,
        .Period      = cfg.Period,
        .PwmMode     = DL_TIMER_PWM_MODE_EDGE_ALIGN_UP,
        .startTimer  = false,
    };
    LQ_TIMER_PWMInit(timer, &pwm_init);           /* 初始化 PWM 定时器 */
    LQ_TIMER_EnablePWMChannel(in1);               /* 使能 IN1 通道 */
    LQ_TIMER_EnablePWMChannel(in2);               /* 使能 IN2 通道 */
    LQ_TIMER_PWMSetCaptureCompare(in1, 0U);       /* 初始占空比 0 */
    LQ_TIMER_PWMSetCaptureCompare(in2, 0U);
    LQ_TIMER_PWM_Start(timer);                    /* 启动定时器 */
}

/*************************************************************************
 * @name     LQ_Motor_SetBridge
 *
 * @brief    设置单侧 H 桥的方向与占空比(AT8236 慢衰减驱动)
 * @param    timer               H 桥占用的定时器枚举
 * @param    in1                 H 桥 IN1 端的 PWM 通道
 * @param    in2                 H 桥 IN2 端的 PWM 通道
 * @param    duty                目标占空比,范围 -10000 ~ +10000(正=正转,负=反转)
 * @param    previous_direction  指向模块内保存的"上次方向"变量,用于换向检测
 *
 * @note     AT8236 慢衰减驱动逻辑:
 *           - 正转:IN1 恒高(load),IN2 输出互补占空比(load - drive)
 *           - 反转:IN2 恒高(load),IN1 输出互补占空比(load - drive)
 *           - 停止:两臂 PWM 都置 0(滑行)
 *           只有方向真正翻转时才先关闭两臂 2μs,避免直通,同时不破坏连续同向 PWM
 *************************************************************************/
static void LQ_Motor_SetBridge(LQEnum_Timer_t timer,
                               LQEnum_PWM_Pin_t in1, LQEnum_PWM_Pin_t in2,
                               int32_t duty, int8_t *previous_direction)
{
    uint32_t load = LQ_TIMER_Regs[timer]->COUNTERREGS.LOAD;
    uint32_t drive_compare;     /* 实际驱动占空比:load * |duty| / 10000 */
    uint32_t decay_compare;     /* 互补比较值(慢衰减段):load - drive */
    int8_t   direction;

    /* 限幅到 -MOTOR_PWM_DUTY_MAX ~ +MOTOR_PWM_DUTY_MAX */
    if (duty >  MOTOR_PWM_DUTY_MAX) duty =  MOTOR_PWM_DUTY_MAX;
    if (duty < -MOTOR_PWM_DUTY_MAX) duty = -MOTOR_PWM_DUTY_MAX;

    /* 实际驱动占空比:load * |duty| / 10000,作为慢衰减高边持续时间 */
    drive_compare = load * (uint32_t)(duty >= 0 ? duty : -duty) / (uint32_t)MOTOR_PWM_DUTY_MAX;
    /* 互补比较值(慢衰减段) */
    decay_compare = load - drive_compare;
    direction = (duty > 0) ? 1 : ((duty < 0) ? -1 : 0);

    if (duty == 0)
    {
        /* 滑行:两臂 PWM 都置 0,记录方向为 0 */
        LQ_TIMER_PWMSetCaptureCompare(in1, 0U);
        LQ_TIMER_PWMSetCaptureCompare(in2, 0U);
        *previous_direction = 0;
        return;
    }

    /* 方向翻转保护:上一帧在转,这一帧要换向时,先关闭两臂 2μs 防直通 */
    if (*previous_direction != 0 && direction != *previous_direction)
    {
        LQ_TIMER_PWMSetCaptureCompare(in1, 0U);
        LQ_TIMER_PWMSetCaptureCompare(in2, 0U);
        delay_us(2);
    }

    if (duty > 0)
    {
        /* 正转:IN1 恒高,IN2 输出慢衰减占空比 */
        LQ_TIMER_PWMSetCaptureCompare(in1, load);
        LQ_TIMER_PWMSetCaptureCompare(in2, decay_compare);
    }
    else
    {
        /* 反转:IN2 恒高,IN1 输出慢衰减占空比 */
        LQ_TIMER_PWMSetCaptureCompare(in2, load);
        LQ_TIMER_PWMSetCaptureCompare(in1, decay_compare);
    }
    *previous_direction = direction;
}

/*************************************************************************
 * @name     LQ_Motor_Init
 *
 * @brief    初始化电机 PWM 通道(双 H 桥,每路 2 通道 PWM)
 * @param    period : 目标 PWM 频率(Hz)
 * @param    duty   : 初始占空比(-MOTOR_PWM_DUTY_MAX ~ MOTOR_PWM_DUTY_MAX)
 * @return   none
 *
 * @note     左电机用 TIMERA1(PB2/PB3),右电机用 TIMERG0(PB10/PB11)
 *           初始化后两路 H 桥都输出 0,需调用 LQ_Motor_SetDuty 才会转动
 *************************************************************************/
void LQ_Motor_Init(uint32_t period, int32_t duty)
{
    /* 清空上次方向记录 */
    s_left_previous_direction  = 0;
    s_right_previous_direction = 0;

    /* 初始化左桥:TIMERA1 + PB2(IN1) + PB3(IN2) */
    LQ_Motor_InitBridge(MOTOR_LEFT_TIMER,  MOTOR_LEFT_IN1_PWM,  MOTOR_LEFT_IN2_PWM,  period);
    /* 初始化右桥:TIMERG0 + PB10(IN1) + PB11(IN2) */
    LQ_Motor_InitBridge(MOTOR_RIGHT_TIMER, MOTOR_RIGHT_IN1_PWM, MOTOR_RIGHT_IN2_PWM, period);

    /* 初始占空比输出 */
    LQ_Motor_SetDuty(MOTOR_CH1, duty);
    LQ_Motor_SetDuty(MOTOR_CH2, duty);
}

/*************************************************************************
 * @name     LQ_Motor_SetDuty
 *
 * @brief    设置指定电机通道的 PWM 占空比
 * @param    ch   : 电机通道(MOTOR_CH1=左, MOTOR_CH2=右)
 * @param    duty : 目标占空比(-MOTOR_PWM_DUTY_MAX ~ MOTOR_PWM_DUTY_MAX, 10000 对应 100%)
 * @return   none
 *
 * @note     内部自动判方向并取绝对值:
 *           duty > 0 = 正转, IN1 恒高, IN2 慢衰减
 *           duty < 0 = 反转, IN2 恒高, IN1 慢衰减
 *           duty = 0 = 滑行, 两臂置 0
 *************************************************************************/
void LQ_Motor_SetDuty(LQEnum_Motor_CH_t ch, int32_t duty)
{
    if (ch == MOTOR_CH1) {
        /* 左电机 */
        LQ_Motor_SetBridge(MOTOR_LEFT_TIMER, MOTOR_LEFT_IN1_PWM, MOTOR_LEFT_IN2_PWM,
                           duty, &s_left_previous_direction);
    } else {
        /* 右电机 */
        LQ_Motor_SetBridge(MOTOR_RIGHT_TIMER, MOTOR_RIGHT_IN1_PWM, MOTOR_RIGHT_IN2_PWM,
                           duty, &s_right_previous_direction);
    }
}
