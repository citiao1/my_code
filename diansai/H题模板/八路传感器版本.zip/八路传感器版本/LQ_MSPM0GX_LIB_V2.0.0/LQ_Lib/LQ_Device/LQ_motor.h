/*******************************************************************************
 * @file                LQ_motor.h
 * @brief               本文件是 LQ_MSPM0GX_LIB 驱动库源文件之一
 * @copyright           版权所有 (C) 2025-2026 龙邱科技科技有限公司
 * @website             http://www.lqist.cn
 * @taobao              http://longqiu.taobao.com
 *
 * @description         龙邱科技 MSPM0G3507 开发板驱动库
 *
 * 硬件运行环境:
 *   - 使用编译器 : Keil5
 *   - 目标芯片 : MSPM0G3507
 *   - 外部晶振 : 16.000MHz
 *   - 系统时钟 : 80MHz
 *
 * 本文件遵循GPL-3.0开源协议发布,宗旨为 MSPM0G3507 芯片嵌入式系统开发者提供一套可在 MSPM0G3507 相关应用层的参考实例
 * 商业用途请联系上方使用授权,使用前请联系上方软件著作权
 *
 * GPL-3.0 许可证条款摘要:
 * 1. 任何人可使用、修改、分发本软件
 * 2. 分发修改后的版本时,必须采用相同开源许可证
 * 3. 必须保留原始版权信息和许可证信息
 * 4. 不提供任何的担保使用方法分别负责
 * 5. 完整协议的副本见项目目录 LICENSE 文件
 *
 * @author              LQ_012
 * @email               chiusir@163.com
 * @version             V2.0.0
 * @update              2026年4月24日
 *******************************************************************************/
#ifndef __LQ_MOTOR_H__
#define __LQ_MOTOR_H__

#include "include.h"

/****************************************************************************************************
 * @brief   宏定义
 ****************************************************************************************************/

#define MOTOR_PWM_SYS_CLOCK         CPUCLK_FREQ /* 定时器频率 */

#define MOTOR_PWM_DUTY_MAX          ( 10000 )   /* 占空比最大映射值, 0=0%, 10000=100% */

/* 左电机占用 TIMERA1 的 CH0/CH1,引脚 PB2/IN1、PB3/IN2 */
#define MOTOR_LEFT_TIMER            LQ_TIMERA_1
#define MOTOR_LEFT_IN1_PWM          LQ_TIMERA1_PWM_CH0_Pin_B_2
#define MOTOR_LEFT_IN2_PWM          LQ_TIMERA1_PWM_CH1_Pin_B_3

/* 右电机占用 TIMERG0 的 CH0/CH1,引脚 PB10/IN1、PB11/IN2 */
#define MOTOR_RIGHT_TIMER           LQ_TIMERG_0
#define MOTOR_RIGHT_IN1_PWM         LQ_TIMERG0_PWM_CH0_Pin_B_10
#define MOTOR_RIGHT_IN2_PWM         LQ_TIMERG0_PWM_CH1_Pin_B_11

/*!
 * @brief       电机通道枚举
 *
 * @note        AT8236 慢衰减驱动:每路电机由 2 个 PWM 通道(IN1+IN2)控制
 *              正转:IN1 恒高,IN2 输出互补占空比(load - drive)
 *              反转:IN2 恒高,IN1 输出互补占空比
 *              换向时先关两臂 2μs 防直通
 */
typedef enum
{
    MOTOR_CH1 = 0,      // 左电机(对应 PB2/PB3 两路 PWM)
    MOTOR_CH2 = 1,      // 右电机(对应 PB10/PB11 两路 PWM)
} LQEnum_Motor_CH_t;

/****************************************************************************************************
 * @brief   函数声明
 ****************************************************************************************************/

void LQ_Motor_Init(uint32_t period, int32_t duty);              /*! @brief  初始化电机 PWM 通道, 设置频率和初始占空比 */

void LQ_Motor_SetDuty(LQEnum_Motor_CH_t ch, int32_t duty);      /*! @brief  设置电机 PWM 占空比 */

#endif
