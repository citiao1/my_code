# 添加运行时间显示功能

## 摘要

注释掉 OLED 原有显示（STATUS / IR标签 / 5路H/L，保留代码不删除），改为显示运行时间。运行时间从按下 K1 启动（`MID_Chassis_Start`）开始计时，到车停止运动（`MID_Chassis_Stop`）停止计时——手动 K1 急停和 5 路传感器触发停止都自动覆盖，因为两者都走 `MID_Chassis_Stop`。显示格式：12 号字体大字秒数。

## 当前状态分析

### OLED 显示（main.c [s_screen_refresh](file:///d:/桌面/My_ele_contest2/LQ_MSPM0GX_LIB_V2.0.0/User/main.c#L120-L159)）
- 每 50ms 刷新一次
- 第 0 行：`STATUS: RUN/STOP/E-STOP`（8号字体）
- 第 1 行：`IR1 IR2 IR3 IR4 IR5`（8号字体）
- 第 2-6 行：5 路 H/L 字符（12号字体）
- 用到的辅助：`format_levels()`、`MID_IR_ReadRaw()`、`MID_Key_IsRunning()`、`g_line_emergency_stopped`

### 底盘启停调用点（grep 确认）
- `MID_Chassis_Start()` 仅在 [mid_key.c:87](file:///d:/桌面/My_ele_contest2/LQ_MSPM0GX_LIB_V2.0.0/Code/Middle/mid_key.c#L87) `s_handle_start` 调用（K1 启动）
- `MID_Chassis_Stop()` 仅在两处调用：
  - [mid_key.c:100](file:///d:/桌面/My_ele_contest2/LQ_MSPM0GX_LIB_V2.0.0/Code/Middle/mid_key.c#L100) `s_handle_stop`（K1 手动急停）
  - [mid_line.c:316](file:///d:/桌面/My_ele_contest2/LQ_MSPM0GX_LIB_V2.0.0/Code/Middle/mid_line.c#L316) `MID_Line_CheckEmergency`（5 路传感器触发停止）
- **两个停止路径都走 `MID_Chassis_Stop`，挂钩此处可同时覆盖两种停止场景**

### 计时源
- `APP_Scheduler_GetTickMs()` 返回 `uint32_t` 毫秒（[app_scheduler.h:46](file:///d:/桌面/My_ele_contest2/LQ_MSPM0GX_LIB_V2.0.0/Code/App/app_scheduler.h#L46)），SysTick 1ms 累加

### OLED API（mid_oled.h）
- `MID_OLED_Clear()` — 清 GRAM + 置脏
- `MID_OLED_ShowString(y, x, str, size)` — y 行号 0~7，x 列 0~127
- `MID_OLED_ShowFloat(y, x, val, prec, size)` — y 行号，prec 小数位
- 12 号字体占 2 行（约 16 像素高）

### mid_chassis.c 当前结构
- 第 26 行 `#include "mid_chassis.h"`（需新增 `#include "app_scheduler.h"`）
- `MID_Chassis_Init()`（第 34 行）：清 PID 状态 + g_chassis 归零
- `MID_Chassis_Start()`（第 163 行）：置 enable_pos/yaw/speed = 1
- `MID_Chassis_Stop()`（第 177 行）：Init + 清 enable + 清 chassis_vx + Motor_Stop

## 提议改动

### 1. mid_chassis.c — 新增运行计时变量 + 挂钩 Start/Stop + getter

新增文件作用域静态变量（紧跟 `g_chassis` 定义之后）：

```c
/* 运行计时状态（由 MID_Chassis_Start 启动，MID_Chassis_Stop 停止） */
static uint32_t s_run_start_ms    = 0U;   /* 启动时刻 tick (ms) */
static uint32_t s_run_elapsed_ms  = 0U;   /* 停止时固化的运行时长 (ms) */
static uint8_t  s_run_timing      = 0U;   /* 1=正在计时，0=已停止 */
```

新增 include（文件顶部，第 26 行后）：
```c
#include "app_scheduler.h"        /* APP_Scheduler_GetTickMs 运行计时 */
```

**修改 `MID_Chassis_Init()`**（初始化时清计时变量，紧跟现有 g_chassis 归零之后）：
```c
    /* 清运行计时状态 */
    s_run_start_ms   = 0U;
    s_run_elapsed_ms = 0U;
    s_run_timing     = 0U;
```

**修改 `MID_Chassis_Start()`**（末尾追加启动计时）：
```c
    g_param.enable_pos   = 1;
    g_param.enable_yaw   = 1;
    g_param.enable_speed = 1;

    /* 启动运行计时 */
    s_run_start_ms = APP_Scheduler_GetTickMs();
    s_run_timing   = 1U;
```

**修改 `MID_Chassis_Stop()`**（在步骤 1 Init 之后、或末尾追加停止计时，用 if 保护避免重复停止覆盖时长）：
```c
    /* 停止运行计时（仅当正在计时才固化时长，避免重复 Stop 覆盖） */
    if (s_run_timing) {
        s_run_elapsed_ms = APP_Scheduler_GetTickMs() - s_run_start_ms;
        s_run_timing = 0U;
    }
```
（放在 `MID_Motor_Stop()` 之前或之后均可，逻辑等价；选放在函数末尾 `MID_Motor_Stop()` 之后。）

**新增 getter `MID_Chassis_GetRunTimeMs()`**（文件末尾）：
```c
/* 获取当前运行时长（毫秒）
 * @return 运行时长 ms：
 *         - 正在计时：now - s_run_start_ms（实时增长）
 *         - 已停止：s_run_elapsed_ms（固化值）
 *         - 未启动过：0
 * @note  供 main.c OLED 显示调用
 */
uint32_t MID_Chassis_GetRunTimeMs(void)
{
    if (s_run_timing) {
        return APP_Scheduler_GetTickMs() - s_run_start_ms;
    }
    return s_run_elapsed_ms;
}
```

### 2. mid_chassis.h — 声明 getter

在 `MID_Chassis_Stop()` 声明之后（约第 103 行后）新增：

```c
/* 获取当前运行时长（毫秒）
 * @return 运行时长 ms（正在计时返回实时值，已停止返回固化值，未启动返回 0）
 * @note  供 main.c OLED 显示调用；计时由 Start/Stop 自动维护
 */
uint32_t MID_Chassis_GetRunTimeMs(void);
```

### 3. main.c — 注释掉原显示 + 新增运行时间显示

**注释掉** `s_screen_refresh()` 内原有显示代码（保留不删除，用 `//` 或 `/* */` 注释）：
- 第 128-130 行：`MID_IR_ReadRaw(levels)` 及 levels 声明
- 第 132-134 行：`format_levels` 调用及 states 声明
- 第 136-145 行：STATUS 字符串判断 + ShowString
- 第 147-148 行：IR 标签 ShowString
- 第 150-158 行：5 路 H/L ShowString 循环
- `format_levels` 函数定义（第 101-108 行）若不再被调用，注释保留（不删除，避免"未使用"警告需配合注释说明）

**新增**运行时间显示（替代原显示内容）：

```c
static void s_screen_refresh(void)
{
    uint32_t now = APP_Scheduler_GetTickMs();
    if ((now - s_last_screen_ms) < SCREEN_REFRESH_MS) {
        return;
    }
    s_last_screen_ms = now;

    /* ===== 原有显示已注释（保留代码不删除） =====
     * ... 原代码注释 ...
     * ============================================= */

    /* 新增：显示运行时间（12号字体大字秒数）
     * 布局：
     *   第 0-1 行 (y=0, size=12)："TIME:"  标签
     *   第 2-3 行 (y=2, size=12)：数值 + "s"
     */
    MID_OLED_Clear();
    MID_OLED_ShowString(0u, 0u, "TIME:", MID_OLED_FONT_12);
    float sec = (float)MID_Chassis_GetRunTimeMs() / 1000.0f;
    MID_OLED_ShowFloat(2u, 0u, sec, 3u, MID_OLED_FONT_12);
    MID_OLED_ShowString(2u, 48u, "s", MID_OLED_FONT_12);
}
```

**main.c 顶部 include**：已 include `mid_chassis.h`（第 39 行），`MID_Chassis_GetRunTimeMs` 可直接调用，无需新增 include。

### 不改动的部分

- `mid_key.c` / `mid_line.c`：启停逻辑不变，计时由 chassis 模块内部自动维护
- `app_scheduler.c`：调度逻辑不变
- `mid_oled.c/.h`：API 不变
- `format_levels` 函数：注释保留（不删除），因不再调用会产生"未使用函数"警告——用 `/* 原显示辅助函数，保留备用 */` 注释包裹或加 `__attribute__((unused))`，按项目风格选注释包裹

## 假设与决策

1. **计时挂钩点**：放 `MID_Chassis_Start`/`Stop` 内部，而非 mid_key.c + mid_line.c 分散挂钩。理由：两个停止路径都走 Stop，集中挂钩零遗漏，且 chassis 模块自然拥有"运行状态"语义。
2. **Stop 重复调用保护**：`if (s_run_timing)` 防止 Stop 被多次调用时覆盖已固化的时长（虽然当前调用点不会重复调 Stop，但防御性保护成本极低且语义更清晰）。
3. **显示格式**：12 号字体，第 0-1 行 "TIME:"，第 2-3 行 秒数+"s"，3 位小数（用户确认）。
4. **Clear 策略**：每次 refresh 先 `MID_OLED_Clear()` 再重绘。50ms 周期 + 40ms 全刷，可接受。原显示注释后残留内容需 Clear 清除。
5. **计时变量类型**：`uint32_t` ms，约 49.7 天溢出，电赛场景足够。
6. **`format_levels` 未使用警告**：用注释包裹整个函数定义消除警告（`/* 原显示辅助，保留备用 static void format_levels... */`），不删除代码。
7. **编码**：mid_chassis.c/h、main.c 均为 GB2312，新增中文注释保持 GB2312。mid_chassis.h 原注释有"锟斤拷"损坏，但本次只在文件末尾追加新声明，不改动损坏注释（遵守"不擅自优化无关代码"）。
8. **Init 清计时变量**：`MID_Chassis_Init` 在 main 初始化和 Stop 内部都被调用。Stop 内调 Init 会清计时变量——**这会破坏 Stop 里刚固化的 elapsed！** 因此计时变量的清零不能放 `MID_Chassis_Init`，只能放 main.c 初始化序列里单独调一次，或用专门的 reset。决策：**不在 Init 里清计时变量**，改在 `MID_Chassis_Start` 里启动时自然重置（start_ms = now, timing = 1），上电默认 0 即可。Stop 里固化 elapsed。再次 Start 重置 start_ms。生命周期自洽，无需 Init 清零。

## 验证步骤

1. Keil5 编译，确保 0 error / 0 warning（特别注意 `format_levels` 注释后是否还有未使用警告）。
2. 静态审查：
   - `MID_Chassis_Start` 后 `s_run_timing=1`，getter 返回实时增长值
   - `MID_Chassis_Stop` 后 `s_run_timing=0`，getter 返回固化 elapsed
   - 再次 Start：`s_run_start_ms` 重置，elapsed 被覆盖（重新计时）
   - 上电未启动：`s_run_timing=0`，elapsed=0，getter 返回 0
3. 烧录实测：
   - 上电 OLED 显示 `TIME:` + `0.000s`
   - 按 K1 启动：时间开始增长
   - 按 K1 急停：时间停止增长，显示固化的运行时长
   - 再次 K1 启动：时间从 0 重新开始增长
   - 让 5 路传感器触发停止：时间停止增长，显示固化时长
4. 确认原 STATUS / IR / H/L 显示已不再出现（被注释）。
