# 紧急停止逻辑改造：3 次滑动窗口「每路都为 L 过」触发

## 摘要

把 5 路红外紧急停止的触发条件，从「5 路同时全为 L（黑线）」改为「最近 3 次检测的滑动窗口内，5 路中每一路都至少出现过一次 L」。去掉原「全 H」检测（原代码注释提及但实际未实现）。窗口语义为滑动窗口（每次新检测滑入、最老滑出，窗口满 3 次后每次检测都判断）。

## 当前状态分析

### 现有逻辑（mid_line.c 第 251-269 行 `MID_Line_CheckEmergency`）

```c
void MID_Line_CheckEmergency(const uint8_t *levels)
{
    int i;
    int all_same = 1;
    /* 仅检查 levels[1..4] 是否全为 0（全 L），未检查 levels[0]，也未真正检查全 1 */
    for (i = 1; i < MID_IR_SENSOR_COUNT; i++) {
        if (levels[i] == 1) { all_same = 0; break; }
    }
    if (all_same && !g_line_emergency_stopped) {
        MID_Chassis_Stop();
        g_line_emergency_stopped = 1U;
    }
}
```

- 触发条件：5 路电平「同一帧」全为 0（全 L）。
- 问题：小车扫过横线/路口时，各传感器并不同时压线，单帧全 L 条件难以命中，导致路口停车不可靠。
- 附带：循环从 `i=1` 起步漏掉 `levels[0]`；注释说「全0或全1」但代码只测全0。

### 调用点与清标志流程

- 调用点：`app_scheduler.c` 第 130 行，每 5ms 一次，参数为 `ir_levels`（原始 GPIO 电平）。
- 清标志：`mid_key.c` 第 81 行 `s_handle_start()` 中 `g_line_emergency_stopped = 0u;`。
- 初始化：`mid_line.c` `MID_IR_Init()` 清 `bits` / `s_prev_bits` / `g_line_emergency_stopped`。

### 电平语义

- `MID_IR_ACTIVE_LOW == 1`（NPN 式）：`levels[i] == 0` 表示低电平 = 检测到黑线 = L。
- 因此「L」↔ `levels[i] == 0`。

## 提议改动

### 1. mid_line.c — 重写 `MID_Line_CheckEmergency` 为滑动窗口 OR 逻辑

新增私有静态变量（文件作用域）：

```c
/* 紧急停止滑动窗口大小：最近 N 次检测 */
#define MID_LINE_EMG_WINDOW  (3)

/* 滑动窗口历史：s_emg_hist[0] = 最近一次，bit i = 1 表示第 i 路在该次为 L */
static uint8_t s_emg_hist[MID_LINE_EMG_WINDOW] = {0};

/* 窗口已积累的检测次数（0 ~ MID_LINE_EMG_WINDOW），未满时不判断 */
static uint8_t s_emg_hist_count = 0U;
```

新逻辑（伪代码）：

```c
void MID_Line_CheckEmergency(const uint8_t *levels)
{
    int i;
    uint8_t cur_mask = 0U;     /* 本次 5 路 L 位图，bit i=1 表示第 i 路为 L */
    uint8_t or_mask;

    /* 1) 计算本次 5 路 L 位图：levels[i]==0 → L → 置 bit i */
    for (i = 0; i < MID_IR_SENSOR_COUNT; i++) {
        if (levels[i] == 0U) {
            cur_mask |= (uint8_t)(1U << i);
        }
    }

    /* 2) 滑动窗口右移，新值放 [0] */
    s_emg_hist[2] = s_emg_hist[1];
    s_emg_hist[1] = s_emg_hist[0];
    s_emg_hist[0] = cur_mask;
    if (s_emg_hist_count < (uint8_t)MID_LINE_EMG_WINDOW) {
        s_emg_hist_count++;
    }

    /* 3) 窗口未满 3 次，不判断（避免上电/重启后误触发） */
    if (s_emg_hist_count < (uint8_t)MID_LINE_EMG_WINDOW) {
        return;
    }

    /* 4) 3 次窗口内 5 路都为 L 过 → 触发停止
     *    OR 起来若 bit0~bit4 全为 1（== 0x1F）则每路都为 L 过 */
    or_mask = s_emg_hist[0] | s_emg_hist[1] | s_emg_hist[2];
    if ((or_mask & 0x1FU) == 0x1FU) {
        if (!g_line_emergency_stopped) {
            MID_Chassis_Stop();
            g_line_emergency_stopped = 1U;
        }
    }
}
```

要点：
- 从 `i=0` 开始遍历全部 5 路（修复原 `i=1` 漏掉 `levels[0]` 的问题，这是新逻辑「每路都为 L 过」的必然要求，不算额外改动）。
- 去掉「全 H」分支（按用户确认）。
- 触发后窗口不清零（保持现状），由 K1 重启时显式调用 `MID_Line_ResetEmergency()` 清零（见下条）。

### 2. mid_line.c / mid_line.h — 新增 `MID_Line_ResetEmergency()` 清窗口 API

新增一个函数，用于在 K1 启动时把窗口历史和计数清零，避免重启后因窗口残留立即再次触发。

mid_line.c 实现：

```c
void MID_Line_ResetEmergency(void)
{
    int i;
    for (i = 0; i < MID_LINE_EMG_WINDOW; i++) {
        s_emg_hist[i] = 0U;
    }
    s_emg_hist_count = 0U;
}
```

mid_line.h 声明 + 注释（放在 `MID_Line_CheckEmergency` 声明之后）：

```c
/* 清空紧急停止滑动窗口历史（K1 启动时调用，避免残留窗口立即触发）
 * @note  仅清 s_emg_hist[] / s_emg_hist_count，不改 g_line_emergency_stopped
 *        （后者由 mid_key.c 单独清）
 */
void MID_Line_ResetEmergency(void);
```

### 3. mid_line.c `MID_IR_Init()` — 初始化时清窗口

在 `MID_IR_Init()` 末尾清零新增的窗口变量（紧跟现有 `g_line_emergency_stopped = 0U;` 之后）：

```c
    /* 清紧急停止滑动窗口 */
    for (i = 0; i < MID_LINE_EMG_WINDOW; i++) {
        s_emg_hist[i] = 0U;
    }
    s_emg_hist_count = 0U;
```

（`i` 变量在 `MID_IR_Init` 内已存在，复用。）

### 4. mid_key.c `s_handle_start()` — K1 启动时清窗口

在第 81 行 `g_line_emergency_stopped = 0u;` 之后，新增一行调用：

```c
    /* 3) 清 5 路灰度传感器紧急停止标志（恢复运行状态用） */
    g_line_emergency_stopped = 0u;

    /* 清紧急停止滑动窗口，避免重启后因窗口残留立即再次触发 */
    MID_Line_ResetEmergency();
```

（mid_key.c 已 include mid_line.h，无需新增 include。）

### 5. mid_line.h — 更新注释

更新文件顶部与 `MID_Line_CheckEmergency` 声明处的注释，把「5路全0/全1」改为「最近 3 次检测滑动窗口内，5 路每路都为 L 过」。注释保持 GB2312 编码（与原文件一致）。

## 不改动的部分

- `app_scheduler.c`：调用接口 `MID_Line_CheckEmergency(ir_levels)` 不变，无需改动。
- `MID_IR_ReadRaw` / `MID_IR_UpdateBits` / `MID_Line_CalcError`：与新逻辑无关，不动。
- `g_line_emergency_stopped` 语义和清标志流程：不变（仍由 mid_key.c 清）。
- 蜂鸣器提示、OLED 显示：不涉及。

## 假设与决策

1. **L 的定义**：`levels[i] == 0`（NPN 式低电平有效 = 黑线 = L），与 `MID_IR_ACTIVE_LOW == 1` 一致。
2. **滑动窗口大小 = 3**：按用户需求「三次检测内」。
3. **窗口不满 3 次不判断**：避免上电/重启后立即误触发。
4. **触发后窗口不清零**：保持与原逻辑一致的「一次性触发」语义；K1 重启时由 `MID_Line_ResetEmergency()` 显式清零。
5. **去掉全 H 检测**：按用户确认，仅保留新逻辑。
6. **`MID_LINE_EMG_WINDOW` 宏放 mid_line.c 内**：私有，不暴露到 .h（不提前提供可配置性）。
7. **编码**：mid_line.c / mid_line.h / mid_key.c 均为 GB2312，新增中文注释保持 GB2312。
8. **修复 `i=1` 起步**：原循环 `for (i=1; ...)` 漏检 `levels[0]`，新逻辑必须遍历全部 5 路，自然修正，不算超范围改动。

## 验证步骤

1. 用 Keil5（D:\keil5）编译，确保 0 error / 0 warning。
2. 静态审查：
   - `MID_LINE_EMG_WINDOW == 3` 时，`s_emg_hist[2]` 索引合法。
   - `0x1FU` 掩码覆盖 bit0~bit4（5 路）。
   - `s_emg_hist_count` 上限为 3，不会溢出。
3. 行为推演（手工验证逻辑正确性）：
   - 上电后前 2 次检测：`s_emg_hist_count < 3`，不判断，不触发。
   - 第 3 次起：每次都判断。
   - 场景 A（横线扫过）：3 次内 5 路依次为 L → OR 后 `== 0x1F` → 触发停止。
   - 场景 B（正常循迹，仅中间路为 L）：OR 后只有 bit2 → `!= 0x1F` → 不触发。
   - 场景 C（K1 重启）：`MID_Line_ResetEmergency()` 清窗口 → 重新积累 3 次后才判断。
4. 烧录后实测：小车经过横线/路口时应能可靠触发停止；正常循迹时无误触发；K1 重启后不立即误触发。
