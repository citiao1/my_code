$path = 'd:\桌面\My_ele_contest2\LQ_MSPM0GX_LIB_V2.0.0\Code\Middle\mid_pid.h'
$bytes = [System.IO.File]::ReadAllBytes($path)
Write-Host ('Total bytes: ' + $bytes.Length)
Write-Host ('First 3 bytes hex: ' + $bytes[0].ToString('X2') + ' ' + $bytes[1].ToString('X2') + ' ' + $bytes[2].ToString('X2'))
# Try detect BOM
if ($bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
    Write-Host 'Has UTF-8 BOM'
} else {
    Write-Host 'No UTF-8 BOM'
}
