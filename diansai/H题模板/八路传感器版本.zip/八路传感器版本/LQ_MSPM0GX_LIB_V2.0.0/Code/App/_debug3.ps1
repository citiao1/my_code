# _debug3.ps1
Set-Location $PSScriptRoot

$srcRel = "app_debug.c"
$text = [System.IO.File]::ReadAllText((Join-Path (Get-Location) $srcRel), [System.Text.Encoding]::UTF8)

# 检查 anchor 字符串
$anchor = @"
    g_param.pid_yaw.imax     = s_parse_float(line, "imax_yaw",g_param.pid_yaw.imax);

    g_param.enable_pos   = (uint8_t)s_parse_float(line, "en_pos",   g_param.enable_pos);
"@

Write-Host ("Anchor length: {0}" -f $anchor.Length)
Write-Host ("Anchor (hex first 50):")
$bytes = [System.Text.Encoding]::UTF8.GetBytes($anchor)
$hex = ($bytes[0..([Math]::Min(80, $bytes.Length-1))] | ForEach-Object { '{0:X2}' -f $_ }) -join ' '
Write-Host $hex

Write-Host ("Text around idx 15000 (hex):")
$sub = $text.Substring(15000, 200)
$bytes2 = [System.Text.Encoding]::UTF8.GetBytes($sub)
$hex2 = ($bytes2[0..([Math]::Min(200, $bytes2.Length-1))] | ForEach-Object { '{0:X2}' -f $_ }) -join ' '
Write-Host $hex2
