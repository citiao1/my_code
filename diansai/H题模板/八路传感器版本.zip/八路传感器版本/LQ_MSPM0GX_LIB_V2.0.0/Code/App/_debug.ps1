# _debug.ps1 — 调试 ReadAllText 能否读取到目标
Set-Location $PSScriptRoot

$srcRel = "app_debug.c"
$text = [System.IO.File]::ReadAllText((Join-Path (Get-Location) $srcRel), [System.Text.Encoding]::UTF8)

# 检查文件中是否包含锚点
$anchor = "imax_yaw"
Write-Host ("Contains 'imax_yaw': {0}" -f $text.Contains($anchor))
Write-Host ("Total length: {0}" -f $text.Length)

# 查看 imax_yaw 周围的字符
$idx = $text.IndexOf($anchor)
if ($idx -ge 0) {
    $sub = $text.Substring($idx - 50, 200)
    Write-Host ("Context: [{0}]" -f $sub)
}

# 看看是 CR 还是 CRLF
$crlfCount = ([regex]::Matches($text, "`r`n")).Count
$lfOnlyCount = ([regex]::Matches($text, "`n")).Count
Write-Host ("CRLF count: {0}, LF count: {1}" -f $crlfCount, $lfOnlyCount)
