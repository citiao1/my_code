# _debug2.ps1
Set-Location $PSScriptRoot

$srcRel = "app_debug.c"
$text = [System.IO.File]::ReadAllText((Join-Path (Get-Location) $srcRel), [System.Text.Encoding]::UTF8)

# 找所有 imax_yaw 出现的位置
$idx = 0
$count = 0
while (($idx = $text.IndexOf("imax_yaw", $idx)) -ge 0) {
    $count++
    $sub = $text.Substring($idx, [Math]::Min(120, $text.Length - $idx))
    Write-Host ("Match #{0} at {1}: [{2}]" -f $count, $idx, $sub)
    $idx += 8
}

Write-Host ("---")
Write-Host ("Total length: {0}" -f $text.Length)
