# _convert_app_debug.ps1 — 在 app_debug.c 的 imax_yaw 行后插入 omega=X 解析
# 注意：app_debug.c 本身就是 UTF-8 编码（注释已损坏），保持原编码不变
Set-Location $PSScriptRoot

$srcRel  = "app_debug.c"
$tmpRel  = "_tmp_app_debug.c"
$oldRel  = "_anchor_old.txt"
$newRel  = "_anchor_new.txt"

# 1) 以 UTF-8 读取源文件、两个 anchor
$text      = [System.IO.File]::ReadAllText((Join-Path (Get-Location) $srcRel), [System.Text.Encoding]::UTF8)
$anchorOld = [System.IO.File]::ReadAllText((Join-Path (Get-Location) $oldRel), [System.Text.Encoding]::UTF8)
$anchorNew = [System.IO.File]::ReadAllText((Join-Path (Get-Location) $newRel), [System.Text.Encoding]::UTF8)

# 2) 把 anchor 统一转为 CRLF（源文件确认是 CRLF）
$anchorOld = $anchorOld -replace "`r`n", "`n"
$anchorOld = $anchorOld -replace "`n", "`r`n"
$anchorOld = $anchorOld -replace "`r`r`n", "`r`n"
$anchorNew = $anchorNew -replace "`r`n", "`n"
$anchorNew = $anchorNew -replace "`n", "`r`n"
$anchorNew = $anchorNew -replace "`r`r`n", "`r`n"

Write-Host ("Text length: {0}" -f $text.Length)
Write-Host ("AnchorOld length: {0}" -f $anchorOld.Length)
Write-Host ("AnchorNew length: {0}" -f $anchorNew.Length)

if ($text.Contains($anchorOld)) {
    $text = $text.Replace($anchorOld, $anchorNew)
    Write-Host "OK: omega=X block inserted"
} else {
    Write-Host "FAIL: anchor not found"
    exit 1
}

# 3) 直接以 UTF-8 写回原文件（保持原编码，不破坏已有内容）
[System.IO.File]::WriteAllText((Join-Path (Get-Location) $srcRel), $text, [System.Text.Encoding]::UTF8)
Write-Host ("Wrote UTF-8 back to app_debug.c, size: {0}" -f (Get-Item (Join-Path (Get-Location) $srcRel)).Length)
