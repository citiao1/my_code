# _test_gbk2.ps1
$srcRel = "app_debug.c"
$text = [System.IO.File]::ReadAllText((Join-Path (Get-Location) $srcRel), [System.Text.Encoding]::UTF8)

# Find first CJK char
$idx = -1
for ($i = 0; $i -lt $text.Length; $i++) {
    $code = [int][char]$text[$i]
    if ($code -ge 0x4E00 -and $code -le 0x9FFF) {
        $idx = $i
        break
    }
}

if ($idx -lt 0) {
    Write-Host "No CJK char found"
} else {
    $sub = $text.Substring($idx, 8)
    Write-Host ("CJK at {0}: [{1}]" -f $idx, $sub)
    foreach ($ch in $sub.ToCharArray()) {
        Write-Host ("  U+{0:X4}" -f [int][char]$ch)
    }
    $enc = [System.Text.Encoding]::GetEncoding(936)
    $bytes = $enc.GetBytes($sub)
    $hex = ($bytes | ForEach-Object { '{0:X2}' -f $_ }) -join ' '
    Write-Host ("GBK bytes: " + $hex)
}
