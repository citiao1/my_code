# _test_gbk.ps1
$content = "差速底盘运动学"
$enc = [System.Text.Encoding]::GetEncoding(936)
$bytes = $enc.GetBytes($content)
$hex = ($bytes | ForEach-Object { '{0:X2}' -f $_ }) -join ' '
Write-Host "GBK: $hex"
$bytes2 = [System.Text.Encoding]::GetEncoding("GB2312").GetBytes($content)
$hex2 = ($bytes2 | ForEach-Object { '{0:X2}' -f $_ }) -join ' '
Write-Host "GB2312: $hex2"

# 试 UTF-8
$bytesU = [System.Text.Encoding]::UTF8.GetBytes($content)
$hexU = ($bytesU | ForEach-Object { '{0:X2}' -f $_ }) -join ' '
Write-Host "UTF8: $hexU"

# 试 char by char
foreach ($ch in $content.ToCharArray()) {
    $b = $enc.GetBytes([string]$ch)
    $hx = ($b | ForEach-Object { '{0:X2}' -f $_ }) -join ' '
    Write-Host ("[{0}] U+{1:X4} -> {2}" -f $ch, [int][char]$ch, $hx)
}
