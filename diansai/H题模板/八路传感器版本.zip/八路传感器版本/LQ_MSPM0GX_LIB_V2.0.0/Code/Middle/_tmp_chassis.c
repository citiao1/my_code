/*******************************************************************************
 * @file    mid_chassis.c
 * @brief   差速底盘运动学 + 三串级 PID 控制实现
 *
 * @note    三串级控制架构：
 *          位置环 PD(error_line) -> target_omega
 *          角速度环 PI(target_omega, gyro_z) -> target_diff
 *          速度环 PI(target_speed_l/r, actual_speed_l/r) -> PWM
 *
 *          差速解算：
 *          target_speed_l = chassis_vx + target_diff / 2
 *          target_speed_r = chassis_vx - target_diff / 2
 *
 *          每步 Step 函数会读 g_param.enable_xxx 决定是否更该环：
 *          - enable=0：不计算，输出上次的 target_xxx（自然衰减到 vx）
 *          - enable=1：正常计算
 *          调参时可单独打开某环，例如"en_pos=1"单独跑位置环
 *
 *          灰度偏差：8 路加权和，位置 -3.5 ~ +3.5，越远越偏离中间一路
 *          应用前加死区 + 限幅到 ±1
 *******************************************************************************/

#include "mid_chassis.h"
#include "LQ_tracking.h"

MID_Chassis_t g_chassis;

/* 8 路灰度归一化权重，位置 -3.5, -2.5, -1.5, -0.5, 0.5, 1.5, 2.5, 3.5 */
static const float s_pos_weight[8] = {
    -3.5f, -2.5f, -1.5f, -0.5f, 0.5f, 1.5f, 2.5f, 3.5f
};

/* 计算 8 路灰度的偏差 e_line（-1 ~ +1）
 * 原理：找出最黑的一路，取加权位置
 * @return 偏差，正=偏离右侧，负=偏离左侧，全黑=0
 */
float MID_Chassis_CalcLineError(void)
{
    /* 找到最黑的一路（值最大） */
    int idx_max = 0;
    float v_max = LQ_Tracking_Value[0];
    for (int i = 1; i < 8; i++) {
        if (LQ_Tracking_Value[i] > v_max) {
            v_max = LQ_Tracking_Value[i];
            idx_max = i;
        }
    }

    /* 没检测到线（全场白）值都偏小，则偏差=0 */
    if (v_max < g_param.line_threshold) {
        return 0.0f;
    }

    /* 最强一路的位置偏差，再除以 3.5 归一化到 -1~+1 */
    float e = s_pos_weight[idx_max] / 3.5f;

    /* 死区 */
    if (e > -g_param.line_deadzone && e < g_param.line_deadzone) {
        e = 0.0f;
    }

    /* 限幅 */
    if (e >  1.0f) e =  1.0f;
    if (e < -1.0f) e = -1.0f;

    return e;
}

void MID_Chassis_Init(void)
{
    MID_PID_Pos_Init(&g_chassis.pos);
    MID_PID_Yaw_Init(&g_chassis.yaw);
    MID_PID_Speed_Init(&g_chassis.speed_l);
    MID_PID_Speed_Init(&g_chassis.speed_r);

    g_chassis.target_omega    = 0.0f;
    g_chassis.target_diff     = 0.0f;
    g_chassis.target_speed_l  = 0.0f;
    g_chassis.target_speed_r  = 0.0f;
    g_chassis.pwm_l           = 0.0f;
    g_chassis.pwm_r           = 0.0f;
    g_chassis.gyro_z_dps      = 0.0f;
    g_chassis.yaw_deg         = 0.0f;
    g_chassis.target_omega_cmd = 0.0f;
}

void MID_Chassis_PosStep(float error_line, float dt_s)
{
    if (g_param.enable_pos) {
        /* 位置环 PD：偏差 -> 目标角速度 */
        g_chassis.target_omega = MID_PID_Pos_Calc(
            &g_param.pid_pos, &g_chassis.pos, error_line, dt_s);
    } else {
        /* 位置环关闭 -> VOFA 直接控制 (omega=X 设值；想直走就发 omega=0) */
        g_chassis.target_omega = g_chassis.target_omega_cmd;
    }
}

void MID_Chassis_YawStep(float target_omega, float gyro_z, float dt_s)
{
    /* 减去陀螺仪零漂（校准） */
    float gyro_corrected = gyro_z - g_param.gyro_offset;

    if (g_param.enable_yaw) {
        /* 角速度环 PI：(目标角速度 - 实际角速度) -> 差速
         * 目标角速度 target_omega 由调用者从 g_chassis.target_omega 显式传入，
         * 因此本函数内部不读取 g_chassis.target_omega，调用关系见上 */
        g_chassis.target_diff = MID_PID_Yaw_Calc(
            &g_param.pid_yaw, &g_chassis.yaw,
            target_omega, gyro_corrected, dt_s);
    } else {
        /* 关闭 -> 差速=0（直走） */
        g_chassis.target_diff = 0.0f;
    }

    /* 差速解算：叠加到底盘目标速度，写入 g_chassis 由速度环调用者读取 */
    g_chassis.target_speed_l = g_param.chassis_vx + g_chassis.target_diff * 0.5f;
    g_chassis.target_speed_r = g_param.chassis_vx - g_chassis.target_diff * 0.5f;

    /* 速度限幅 */
    if (g_chassis.target_speed_l >  g_param.speed_max) g_chassis.target_speed_l =  g_param.speed_max;
    if (g_chassis.target_speed_l < -g_param.speed_max) g_chassis.target_speed_l = -g_param.speed_max;
    if (g_chassis.target_speed_r >  g_param.speed_max) g_chassis.target_speed_r =  g_param.speed_max;
    if (g_chassis.target_speed_r < -g_param.speed_max) g_chassis.target_speed_r = -g_param.speed_max;
}

void MID_Chassis_SpeedStep(float target_speed_l, float target_speed_r,
                           float speed_l, float speed_r, float dt_s)
{
    if (g_param.enable_speed) {
        /* 左右速度环 PI -> PWM */
        /* 目标速度 target_speed_l/r 由调用者从 g_chassis.target_speed_l/r 显式传入，
           因此本函数内部不读取 g_chassis，调用关系见上 */
        g_chassis.pwm_l = MID_PID_Speed_Calc(
            &g_param.pid_speed_l, &g_chassis.speed_l,
            target_speed_l, speed_l, dt_s);

        g_chassis.pwm_r = MID_PID_Speed_Calc(
            &g_param.pid_speed_r, &g_chassis.speed_r,
            target_speed_r, speed_r, dt_s);
    } else {
        /* 关闭速度环 -> PWM=0（不输出） */
        g_chassis.pwm_l = 0.0f;
        g_chassis.pwm_r = 0.0f;
    }

    /* 下发到电机 */
    MID_Motor_SetDuty(MID_MOTOR_LEFT,  (int32_t)g_chassis.pwm_l);
    MID_Motor_SetDuty(MID_MOTOR_RIGHT, (int32_t)g_chassis.pwm_r);
}

void MID_Chassis_EmergencyStop(void)
{
    MID_Chassis_Init();
    MID_Motor_Stop();
}
