#ifndef __MID_CHASSIS_H__
#define __MID_CHASSIS_H__

/*******************************************************************************
 * @file    mid_chassis.h
 * @brief   差速底盘运动学 + 三串级 PID 控制器（Middle Layer）
 *
 * @note    三串级 PID 控制算法封装在一起，调用者只需提供：
 *          - 灰度偏差 e_line
 *          - 陀螺仪角速度 gyro_z
 *          - 左右编码器实际速度
 *
 *          内部自动完成：
 *          [位置环 PD] -> target_omega
 *          [角速度环 PI] -> target_diff
 *          [速度环 PI x 2] -> PWM_L, PWM_R
 *
 *          调用节奏由调用者保证，建议：位置环 20ms / 角速度环 10ms / 速度环 5ms
 *          本模块不检查时间，调用者按需调用对应步骤函数
 *
 *          VOFA 直接控制中环：
 *          en_pos=0 时，PosStep 不再走位置环，而是把 target_omega_cmd 作为
 *          g_chassis.target_omega 写出去；调用方发 omega=X 即可直接给角速度目标。
 *******************************************************************************/

#include "mid_pid.h"
#include "mid_motor.h"
#include "mid_encoder.h"

/* ============================================================
 *  三环状态量
 * ============================================================ */
typedef struct {
    MID_PID_Pos_State_t   pos;        /* 位置环状态 */
    MID_PID_Yaw_State_t   yaw;        /* 角速度环状态 */
    MID_PID_Speed_State_t speed_l;    /* 左轮速度环状态 */
    MID_PID_Speed_State_t speed_r;    /* 右轮速度环状态 */

    /* 中间变量（VOFA+ 调试观察用） */
    float target_omega;               /* 位置环输出的目标角速度 (deg/s) */
    float target_diff;                /* 角速度环输出的差速 (脉冲/5ms) */
    float target_speed_l;             /* 左轮目标速度 */
    float target_speed_r;             /* 右轮目标速度 */
    float pwm_l;                      /* 左电机下发 PWM */
    float pwm_r;                      /* 右电机下发 PWM */
    float gyro_z_dps;                 /* 陀螺仪 Z 轴原始角速度 (deg/s)，供 VOFA 调试用 */
    float yaw_deg;                    /* SFLP 解算的偏航角 (deg)，5ms 由调度器刷新 */
    float target_omega_cmd;           /* VOFA 直接控制的中环目标角速度 (deg/s)，仅在 en_pos=0 时生效 */
} MID_Chassis_t;

/* 全局底盘实例 */
extern MID_Chassis_t g_chassis;

/* 初始化函数，清空所有 PID 状态 */
void MID_Chassis_Init(void);

/* 计算 8 路灰度的偏差 e_line（-1 ~ +1）
 * @note  由调用者在 5ms 中断里调用，内部读 LQ_Tracking_Value
 *        找最黑一路的加权位置偏差，加死区 + 限幅
 * @return 偏差，正=偏离右侧，负=偏离左侧，全黑=0
 */
float MID_Chassis_CalcLineError(void);

/* ---- 位置环（5ms 调一次）----
 * @param error_line  灰度偏差（约：负值偏左，正值偏右）
 * @param dt_s        时间步长（秒）
 * 输出 g_chassis.target_omega
 * @note  enable_pos=1：跑位置环 PD；enable_pos=0：直接把 target_omega_cmd 写出去
 *        （VOFA 发 omega=X 设值；想直走就发 omega=0）
 */
void MID_Chassis_PosStep(float error_line, float dt_s);

/* ---- 角速度环（5ms 调一次）----
 * @param target_omega 目标角速度 (deg/s)，由位置环计算得到
 *                     调用者从 g_chassis.target_omega 显式传入（本函数内部不读取）
 * @param gyro_z       陀螺仪 Z 轴角速度（deg/s）实际测量值
 * @param dt_s         时间步长（秒）
 * 输出 g_chassis.target_diff / target_speed_l / target_speed_r
 *
 * @note 调用关系：位置环(PosStep) 写 g_chassis.target_omega，
 *       角速度环被调用者显式传入 -> 写 g_chassis.target_speed_l/r
 */
void MID_Chassis_YawStep(float target_omega, float gyro_z, float dt_s);

/* ---- 速度环（5ms 调一次）----
 * @param target_speed_l 左轮目标速度 (m/s)，由角速度环差速解算得到
 *                       调用者从 g_chassis.target_speed_l 显式传入（本函数内部不读取）
 * @param target_speed_r 右轮目标速度 (m/s)，由角速度环差速解算得到
 *                       调用者从 g_chassis.target_speed_r 显式传入（本函数内部不读取）
 * @param speed_l        左轮实际速度 (m/s)
 * @param speed_r        右轮实际速度 (m/s)
 * @param dt_s           时间步长（秒）
 * 输出 g_chassis.pwm_l / pwm_r，再下发到电机
 *
 * @note 调用关系：角速度环(YawStep) 写 g_chassis.target_speed_l/r，
 *       速度环被调用者显式传入 -> 写 g_chassis.pwm_l/r -> 下发电机
 */
void MID_Chassis_SpeedStep(float target_speed_l, float target_speed_r,
                           float speed_l, float speed_r, float dt_s);

/* 急停：复位 + 停电机 */
void MID_Chassis_EmergencyStop(void);

#endif
