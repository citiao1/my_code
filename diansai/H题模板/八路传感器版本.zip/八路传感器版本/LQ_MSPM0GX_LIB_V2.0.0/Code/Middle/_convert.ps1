# _convert.ps1 - 把 UTF-8 临时源文件转 GBK 编码写回目标
Set-Location $PSScriptRoot

$gbk = [System.Text.Encoding]::GetEncoding(936)

$jobs = @(
    @{ Src = "_tmp_chassis.c"; Dst = "mid_chassis.c" },
    @{ Src = "_tmp_chassis.h"; Dst = "mid_chassis.h" }
)

foreach ($j in $jobs) {
    $src = Join-Path (Get-Location) $j.Src
    $dst = Join-Path (Get-Location) $j.Dst
    if (-not (Test-Path $src)) { Write-Host "MISS: $src"; exit 1 }
    $content = [System.IO.File]::ReadAllText($src, [System.Text.Encoding]::UTF8)
    [System.IO.File]::WriteAllText($dst, $content, $gbk)
    $bytes = [System.IO.File]::ReadAllBytes($dst)
    $fffd = 0
    for ($i = 0; $i -le $bytes.Length - 3; $i++) {
        if ($bytes[$i] -eq 0xEF -and $bytes[$i+1] -eq 0xBF -and $bytes[$i+2] -eq 0xBD) { $fffd++ }
    }
    Write-Host ("OK {0} -> {1} (FFFD={2}, size={3})" -f $j.Src, $j.Dst, $fffd, $bytes.Length)
}
