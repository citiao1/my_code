/*******************************************************************************
 * @file                LQ_pwm.c
 * @brief               ���ļ��� LQ_MSPM0GX_LIB ������Դ���ļ���һ����
 * @copyright           ��Ȩ���� (C) 2025-2026 ��������Ƽ����޹�˾
 * @website             http://www.lqist.cn
 * @taobao              http://longqiu.taobao.com
 *
 * @description         ����Ƽ� MSPM0G3507 ���İ�����������
 *
 * ������������:
 *   - ʹ�û��� : Keil5
 *   - Ŀ��оƬ : MSPM0G3507
 *   - ���þ��� : 16.000MHz
 *   - ϵͳʱ�� : 80MHz
 *
 * ���ļ���ѭGPL-3.0��ԴЭ�鷢����ּ��Ϊ MSPM0G3507 оƬǶ��ʽϵͳ����ṩ�������ֿ������� MSPM0G3507 ��Ӧ�ó���Ĳο�ʵ��
 * ��ҵ��;��������λʹ�ã�����ǰ��ϵ���߻����Ȩ
 *
 * GPL-3.0 ����֤����ժҪ:
 * 1. ��������ʹ�á��޸ġ��ַ�������
 * 2. �ַ��޸ĺ�İ汾ʱ����������ͬ����֤����
 * 3. ���뱣��ԭʼ��Ȩ����������֤��Ϣ
 * 4. ���ṩ�κε�����ʹ�÷����Ը�
 * 5. ����Э���ı���μ���Ŀ��Ŀ¼ LICENSE �ļ�
 *
 * @author				wuwu	(�ӿڲ��д)
 * @author              LQ_012	(�Ż���Ӧ�ò��д)
 * @email               chiusir@163.com
 * @version             V2.0.0
 * @update              2026��4��24��
 *******************************************************************************/
#include "LQ_pwm.h"

/*!
 * @brief       PWM����ӳ���
 * 
 * @note        �ڲ�ʹ��, �ⲿ��ֹ�޸�
 */
static const uint8_t LQ_PWM_MAP[][4] = {

    /* TIMA0 CH0 Pin */
    {GPIO_Pin_A_0 , IOMUX_PINCM1_PF_TIMA0_CCP0 , DL_TIMER_CC_0_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_A_8 , IOMUX_PINCM19_PF_TIMA0_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_A_21, IOMUX_PINCM46_PF_TIMA0_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_B_8 , IOMUX_PINCM25_PF_TIMA0_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_B_14, IOMUX_PINCM31_PF_TIMA0_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERA_0},

    /* TIMA0 CH1 Pin */
    {GPIO_Pin_A_1 , IOMUX_PINCM2_PF_TIMA0_CCP1 , DL_TIMER_CC_1_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_A_3 , IOMUX_PINCM8_PF_TIMA0_CCP1 , DL_TIMER_CC_1_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_A_7 , IOMUX_PINCM14_PF_TIMA0_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_A_9 , IOMUX_PINCM20_PF_TIMA0_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_A_22, IOMUX_PINCM47_PF_TIMA0_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_B_9 , IOMUX_PINCM26_PF_TIMA0_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_B_12, IOMUX_PINCM29_PF_TIMA0_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_B_20, IOMUX_PINCM48_PF_TIMA0_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERA_0},

    /* TIMA0 CH2 Pin */
    {GPIO_Pin_A_3 , IOMUX_PINCM8_PF_TIMA0_CCP2 , DL_TIMER_CC_2_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_A_7 , IOMUX_PINCM14_PF_TIMA0_CCP2, DL_TIMER_CC_2_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_A_10, IOMUX_PINCM21_PF_TIMA0_CCP2, DL_TIMER_CC_2_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_A_15, IOMUX_PINCM37_PF_TIMA0_CCP2, DL_TIMER_CC_2_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_B_0 , IOMUX_PINCM12_PF_TIMA0_CCP2, DL_TIMER_CC_2_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_B_4 , IOMUX_PINCM17_PF_TIMA0_CCP2, DL_TIMER_CC_2_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_B_12, IOMUX_PINCM29_PF_TIMA0_CCP2, DL_TIMER_CC_2_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_B_17, IOMUX_PINCM43_PF_TIMA0_CCP2, DL_TIMER_CC_2_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_B_20, IOMUX_PINCM48_PF_TIMA0_CCP2, DL_TIMER_CC_2_INDEX, LQ_TIMERA_0},

    /* TIMA0 CH3 Pin */
    {GPIO_Pin_A_4 , IOMUX_PINCM9_PF_TIMA0_CCP3 , DL_TIMER_CC_3_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_A_12, IOMUX_PINCM34_PF_TIMA0_CCP3, DL_TIMER_CC_3_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_A_17, IOMUX_PINCM39_PF_TIMA0_CCP3, DL_TIMER_CC_3_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_A_23, IOMUX_PINCM53_PF_TIMA0_CCP3, DL_TIMER_CC_3_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_A_25, IOMUX_PINCM55_PF_TIMA0_CCP3, DL_TIMER_CC_3_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_A_28, IOMUX_PINCM3_PF_TIMA0_CCP3 , DL_TIMER_CC_3_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_B_2 , IOMUX_PINCM15_PF_TIMA0_CCP3, DL_TIMER_CC_3_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_B_13, IOMUX_PINCM30_PF_TIMA0_CCP3, DL_TIMER_CC_3_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_B_24, IOMUX_PINCM52_PF_TIMA0_CCP3, DL_TIMER_CC_3_INDEX, LQ_TIMERA_0},
    {GPIO_Pin_B_26, IOMUX_PINCM57_PF_TIMA0_CCP3, DL_TIMER_CC_3_INDEX, LQ_TIMERA_0},

    /* TIMA1 CH0 Pin */
    {GPIO_Pin_A_10, IOMUX_PINCM21_PF_TIMA1_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_A_15, IOMUX_PINCM37_PF_TIMA1_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_A_17, IOMUX_PINCM39_PF_TIMA1_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_A_28, IOMUX_PINCM3_PF_TIMA1_CCP0 , DL_TIMER_CC_0_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_B_0 , IOMUX_PINCM12_PF_TIMA1_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_B_2 , IOMUX_PINCM15_PF_TIMA1_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_B_4 , IOMUX_PINCM17_PF_TIMA1_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_B_17, IOMUX_PINCM43_PF_TIMA1_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_B_26, IOMUX_PINCM57_PF_TIMA1_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERA_1},

    /* TIMA1 CH1 Pin */
    {GPIO_Pin_A_11, IOMUX_PINCM22_PF_TIMA1_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_A_16, IOMUX_PINCM38_PF_TIMA1_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_A_18, IOMUX_PINCM40_PF_TIMA1_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_A_24, IOMUX_PINCM54_PF_TIMA1_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_A_31, IOMUX_PINCM6_PF_TIMA1_CCP1 , DL_TIMER_CC_1_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_B_1 , IOMUX_PINCM13_PF_TIMA1_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_B_3 , IOMUX_PINCM16_PF_TIMA1_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_B_5 , IOMUX_PINCM18_PF_TIMA1_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_B_18, IOMUX_PINCM44_PF_TIMA1_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERA_1},
    {GPIO_Pin_B_27, IOMUX_PINCM58_PF_TIMA1_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERA_1},

    /* TIMG0 CH0 Pin */
    {GPIO_Pin_A_5 , IOMUX_PINCM10_PF_TIMG0_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_0},
    {GPIO_Pin_A_12, IOMUX_PINCM34_PF_TIMG0_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_0},
    {GPIO_Pin_A_23, IOMUX_PINCM53_PF_TIMG0_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_0},
    {GPIO_Pin_B_10, IOMUX_PINCM27_PF_TIMG0_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_0},

    /* TIMG0 CH1 Pin */
    {GPIO_Pin_A_6 , IOMUX_PINCM11_PF_TIMG0_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_0},
    {GPIO_Pin_A_13, IOMUX_PINCM35_PF_TIMG0_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_0},
    {GPIO_Pin_A_24, IOMUX_PINCM54_PF_TIMG0_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_0},
    {GPIO_Pin_B_11, IOMUX_PINCM28_PF_TIMG0_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_0},

    /* TIMG6 CH0 Pin */
    {GPIO_Pin_A_5 , IOMUX_PINCM10_PF_TIMG6_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_6},
    {GPIO_Pin_A_21, IOMUX_PINCM46_PF_TIMG6_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_6},
    {GPIO_Pin_A_29, IOMUX_PINCM4_PF_TIMG6_CCP0 , DL_TIMER_CC_0_INDEX, LQ_TIMERG_6},
    {GPIO_Pin_B_2 , IOMUX_PINCM15_PF_TIMG6_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_6},
    {GPIO_Pin_B_6 , IOMUX_PINCM23_PF_TIMG6_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_6},
    {GPIO_Pin_B_10, IOMUX_PINCM27_PF_TIMG6_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_6},
    {GPIO_Pin_B_26, IOMUX_PINCM57_PF_TIMG6_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_6},

    /* TIMG6 CH1 Pin */
    {GPIO_Pin_A_6 , IOMUX_PINCM11_PF_TIMG6_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_6},
    {GPIO_Pin_A_22, IOMUX_PINCM47_PF_TIMG6_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_6},
    {GPIO_Pin_A_30, IOMUX_PINCM5_PF_TIMG6_CCP1 , DL_TIMER_CC_1_INDEX, LQ_TIMERG_6},
    {GPIO_Pin_B_3 , IOMUX_PINCM16_PF_TIMG6_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_6},
    {GPIO_Pin_B_7 , IOMUX_PINCM24_PF_TIMG6_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_6},
    {GPIO_Pin_B_11, IOMUX_PINCM28_PF_TIMG6_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_6},
    {GPIO_Pin_B_27, IOMUX_PINCM58_PF_TIMG6_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_6},

    /* TIMG7 CH0 Pin */
    {GPIO_Pin_A_3 , IOMUX_PINCM8_PF_TIMG7_CCP0 , DL_TIMER_CC_0_INDEX, LQ_TIMERG_7},
    {GPIO_Pin_A_17, IOMUX_PINCM39_PF_TIMG7_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_7},
    {GPIO_Pin_A_23, IOMUX_PINCM53_PF_TIMG7_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_7},
    {GPIO_Pin_A_26, IOMUX_PINCM59_PF_TIMG7_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_7},
    {GPIO_Pin_A_28, IOMUX_PINCM3_PF_TIMG7_CCP0 , DL_TIMER_CC_0_INDEX, LQ_TIMERG_7},
    {GPIO_Pin_B_15, IOMUX_PINCM32_PF_TIMG7_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_7},

    /* TIMG7 CH1 Pin */
    {GPIO_Pin_A_2 , IOMUX_PINCM7_PF_TIMG7_CCP1 , DL_TIMER_CC_1_INDEX, LQ_TIMERG_7},
    {GPIO_Pin_A_4 , IOMUX_PINCM9_PF_TIMG7_CCP1 , DL_TIMER_CC_1_INDEX, LQ_TIMERG_7},
    {GPIO_Pin_A_7 , IOMUX_PINCM14_PF_TIMG7_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_7},
    {GPIO_Pin_A_18, IOMUX_PINCM40_PF_TIMG7_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_7},
    {GPIO_Pin_A_24, IOMUX_PINCM54_PF_TIMG7_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_7},
    {GPIO_Pin_A_27, IOMUX_PINCM60_PF_TIMG7_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_7},
    {GPIO_Pin_A_31, IOMUX_PINCM6_PF_TIMG7_CCP1 , DL_TIMER_CC_1_INDEX, LQ_TIMERG_7},
    {GPIO_Pin_B_16, IOMUX_PINCM33_PF_TIMG7_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_7},
    {GPIO_Pin_B_19, IOMUX_PINCM45_PF_TIMG7_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_7},

    /* TIMG8 CH0 Pin */
    {GPIO_Pin_A_1 , IOMUX_PINCM2_PF_TIMG8_CCP0 , DL_TIMER_CC_0_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_A_3 , IOMUX_PINCM8_PF_TIMG8_CCP0 , DL_TIMER_CC_0_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_A_5 , IOMUX_PINCM10_PF_TIMG8_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_A_7 , IOMUX_PINCM14_PF_TIMG8_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_A_21, IOMUX_PINCM46_PF_TIMG8_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_A_23, IOMUX_PINCM53_PF_TIMG8_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_A_26, IOMUX_PINCM59_PF_TIMG8_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_A_29, IOMUX_PINCM4_PF_TIMG8_CCP0 , DL_TIMER_CC_0_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_B_6 , IOMUX_PINCM23_PF_TIMG8_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_B_10, IOMUX_PINCM27_PF_TIMG8_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_B_15, IOMUX_PINCM32_PF_TIMG8_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_B_21, IOMUX_PINCM49_PF_TIMG8_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_8},

    /* TIMG8 CH1 Pin */
    {GPIO_Pin_A_0 , IOMUX_PINCM1_PF_TIMG8_CCP1 , DL_TIMER_CC_1_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_A_2 , IOMUX_PINCM7_PF_TIMG8_CCP1 , DL_TIMER_CC_1_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_A_4 , IOMUX_PINCM9_PF_TIMG8_CCP1 , DL_TIMER_CC_1_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_A_6 , IOMUX_PINCM11_PF_TIMG8_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_A_22, IOMUX_PINCM47_PF_TIMG8_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_A_27, IOMUX_PINCM60_PF_TIMG8_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_A_30, IOMUX_PINCM5_PF_TIMG8_CCP1 , DL_TIMER_CC_1_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_B_7 , IOMUX_PINCM24_PF_TIMG8_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_B_11, IOMUX_PINCM28_PF_TIMG8_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_B_16, IOMUX_PINCM33_PF_TIMG8_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_B_19, IOMUX_PINCM45_PF_TIMG8_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_8},
    {GPIO_Pin_B_22, IOMUX_PINCM50_PF_TIMG8_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_8},

    /* TIMG12 CH0 Pin */
    {GPIO_Pin_A_10, IOMUX_PINCM21_PF_TIMG12_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_12},
    {GPIO_Pin_A_14, IOMUX_PINCM36_PF_TIMG12_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_12},
    {GPIO_Pin_B_13, IOMUX_PINCM30_PF_TIMG12_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_12},
    {GPIO_Pin_B_20, IOMUX_PINCM48_PF_TIMG12_CCP0, DL_TIMER_CC_0_INDEX, LQ_TIMERG_12},

    /* TIMG12 CH1 Pin */
    {GPIO_Pin_A_25, IOMUX_PINCM55_PF_TIMG12_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_12},
    {GPIO_Pin_A_31, IOMUX_PINCM6_PF_TIMG12_CCP1 , DL_TIMER_CC_1_INDEX, LQ_TIMERG_12},
    {GPIO_Pin_B_14, IOMUX_PINCM31_PF_TIMG12_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_12},
    {GPIO_Pin_B_24, IOMUX_PINCM52_PF_TIMG12_CCP1, DL_TIMER_CC_1_INDEX, LQ_TIMERG_12},

};

/*************************************************************************
 * @brief       ��ʱ������PWM��ʼ��
 * 
 * @param       TIMER           ��ʱ��ö��
 * @param       TimerPWM_Init   PWM���ýṹ��
 * 
 * @example     LQConfig_PWM_InitTypeDef pwm_config = {
 *                  .DivideRatio = DL_TIMER_CLOCK_DIVIDE_8,
 *                  .Prescaler   = 100 - 1,
 *                  .Period      = 49999,
 *                  .PwmMode     = DL_TIMER_PWM_MODE_EDGE_ALIGN_UP,
 *                  .startTimer  = true
 *              };
 *              LQ_TIMER_PWMInit(LQ_TIMERA_0, &pwm_config);
 *************************************************************************/
void LQ_TIMER_PWMInit(LQEnum_Timer_t TIMER, LQConfig_PWM_InitTypeDef_t *PWM_Init)
{
    GPTIMER_Regs *timer = LQ_TIMER_Regs[TIMER];

    timer->CLKSEL = (uint32_t)DL_TIMER_CLOCK_BUSCLK;
    
    timer->CLKDIV = (uint32_t)PWM_Init->DivideRatio;
    
    timer->COMMONREGS.CPS = (uint32_t)PWM_Init->Prescaler;

    if( TIMER == LQ_TIMERA_0 )
    {
        switch (PWM_Init->PwmMode)
        {
        case DL_TIMER_PWM_MODE_EDGE_ALIGN:
            DL_Timer_setCaptureCompareAction(timer,
                (DL_TIMER_CC_LACT_CCP_HIGH | DL_TIMER_CC_CDACT_CCP_LOW),
                DL_TIMER_CC_2_INDEX);
            DL_Timer_setCaptureCompareAction(timer,
                (DL_TIMER_CC_LACT_CCP_HIGH | DL_TIMER_CC_CDACT_CCP_LOW),
                DL_TIMER_CC_3_INDEX);
        break;

        case DL_TIMER_PWM_MODE_EDGE_ALIGN_UP:
            DL_Timer_setCaptureCompareAction(timer,
                (DL_TIMER_CC_ZACT_CCP_HIGH | DL_TIMER_CC_CUACT_CCP_LOW),
                DL_TIMER_CC_2_INDEX);
            DL_Timer_setCaptureCompareAction(timer,
                (DL_TIMER_CC_ZACT_CCP_HIGH | DL_TIMER_CC_CUACT_CCP_LOW),
                DL_TIMER_CC_3_INDEX);
        break;

        default:
            DL_Timer_setCaptureCompareAction(timer,
                (DL_TIMER_CC_CUACT_CCP_HIGH | DL_TIMER_CC_CDACT_CCP_LOW),
                DL_TIMER_CC_2_INDEX);
            DL_Timer_setCaptureCompareAction(timer,
                (DL_TIMER_CC_CUACT_CCP_HIGH | DL_TIMER_CC_CDACT_CCP_LOW),
                DL_TIMER_CC_3_INDEX);
            break;
        }

        DL_Timer_setCaptureCompareCtl(
            timer, DL_TIMER_CC_MODE_COMPARE, 0, DL_TIMER_CC_2_INDEX);

        DL_Timer_setCaptureCompareCtl(
            timer, DL_TIMER_CC_MODE_COMPARE, 0, DL_TIMER_CC_3_INDEX);

        DL_Timer_setCaptureCompareOutCtl(timer,
            DL_TIMER_CC_OCTL_INIT_VAL_LOW, DL_TIMER_CC_OCTL_INV_OUT_DISABLED,
            DL_TIMER_CC_OCTL_SRC_FUNCVAL, DL_TIMER_CC_2_INDEX);

        DL_Timer_setCaptureCompareOutCtl(timer,
            DL_TIMER_CC_OCTL_INIT_VAL_LOW, DL_TIMER_CC_OCTL_INV_OUT_DISABLED,
            DL_TIMER_CC_OCTL_SRC_FUNCVAL, DL_TIMER_CC_3_INDEX);

        DL_Timer_setCaptureCompareInput(timer,
            DL_TIMER_CC_INPUT_INV_NOINVERT, DL_TIMER_CC_IN_SEL_CCPX,
            DL_TIMER_CC_2_INDEX);

        DL_Timer_setCaptureCompareInput(timer,
            DL_TIMER_CC_INPUT_INV_NOINVERT, DL_TIMER_CC_IN_SEL_CCPX,
            DL_TIMER_CC_3_INDEX);
    }

    switch (PWM_Init->PwmMode) {
        case DL_TIMER_PWM_MODE_EDGE_ALIGN:
            DL_Timer_setLoadValue(timer, (PWM_Init->Period - (uint32_t) 1));
            DL_Timer_setCaptureCompareAction(timer,
                (DL_TIMER_CC_LACT_CCP_HIGH | DL_TIMER_CC_CDACT_CCP_LOW),
                DL_TIMER_CC_0_INDEX);
            DL_Timer_setCaptureCompareAction(timer,
                (DL_TIMER_CC_LACT_CCP_HIGH | DL_TIMER_CC_CDACT_CCP_LOW),
                DL_TIMER_CC_1_INDEX);
            break;
        case DL_TIMER_PWM_MODE_EDGE_ALIGN_UP:
            DL_Timer_setLoadValue(timer, (PWM_Init->Period - (uint32_t) 1));
            DL_Timer_setCaptureCompareAction(timer,
                (DL_TIMER_CC_ZACT_CCP_HIGH | DL_TIMER_CC_CUACT_CCP_LOW),
                DL_TIMER_CC_0_INDEX);
            DL_Timer_setCaptureCompareAction(timer,
                (DL_TIMER_CC_ZACT_CCP_HIGH | DL_TIMER_CC_CUACT_CCP_LOW),
                DL_TIMER_CC_1_INDEX);
            DL_Timer_setCounterValueAfterEnable(
                timer, DL_TIMER_COUNT_AFTER_EN_ZERO);
            break;
        default:  // DL_TIMER_PWM_MODE_CENTER_ALIGN
            DL_Timer_setLoadValue(timer, (PWM_Init->Period >> 1));
            DL_Timer_setCaptureCompareAction(timer,
                (DL_TIMER_CC_CUACT_CCP_HIGH | DL_TIMER_CC_CDACT_CCP_LOW),
                DL_TIMER_CC_0_INDEX);
            DL_Timer_setCaptureCompareAction(timer,
                (DL_TIMER_CC_CUACT_CCP_HIGH | DL_TIMER_CC_CDACT_CCP_LOW),
                DL_TIMER_CC_1_INDEX);
            break;
    }

    DL_Timer_setCaptureCompareCtl(
        timer, DL_TIMER_CC_MODE_COMPARE, 0, DL_TIMER_CC_0_INDEX);

    DL_Timer_setCaptureCompareCtl(
        timer, DL_TIMER_CC_MODE_COMPARE, 0, DL_TIMER_CC_1_INDEX);

    DL_Timer_setCaptureCompareOutCtl(timer, DL_TIMER_CC_OCTL_INIT_VAL_LOW,
        DL_TIMER_CC_OCTL_INV_OUT_DISABLED, DL_TIMER_CC_OCTL_SRC_FUNCVAL,
        DL_TIMER_CC_0_INDEX);

    DL_Timer_setCaptureCompareOutCtl(timer, DL_TIMER_CC_OCTL_INIT_VAL_LOW,
        DL_TIMER_CC_OCTL_INV_OUT_DISABLED, DL_TIMER_CC_OCTL_SRC_FUNCVAL,
        DL_TIMER_CC_1_INDEX);

    DL_Timer_setCaptureCompareInput(timer, DL_TIMER_CC_INPUT_INV_NOINVERT,
        DL_TIMER_CC_IN_SEL_CCPX, DL_TIMER_CC_0_INDEX);

    DL_Timer_setCaptureCompareInput(timer, DL_TIMER_CC_INPUT_INV_NOINVERT,
        DL_TIMER_CC_IN_SEL_CCPX, DL_TIMER_CC_1_INDEX);

    DL_Common_updateReg(&timer->COUNTERREGS.CTRCTL,
        (GPTIMER_CTRCTL_REPEAT_REPEAT_1 | (uint32_t) PWM_Init->PwmMode |
            (uint32_t) PWM_Init->startTimer),
        (GPTIMER_CTRCTL_CZC_MASK | GPTIMER_CTRCTL_CAC_MASK |
            GPTIMER_CTRCTL_CLC_MASK | GPTIMER_CTRCTL_CVAE_MASK |
            GPTIMER_CTRCTL_CM_MASK | GPTIMER_CTRCTL_REPEAT_MASK |
            GPTIMER_CTRCTL_EN_MASK));

    DL_Timer_setCounterControl(timer,
        DL_TIMER_CZC_CCCTL0_ZCOND, 
        DL_TIMER_CAC_CCCTL0_ACOND, 
        DL_TIMER_CLC_CCCTL0_LCOND);

    DL_Timer_enableClock(timer);

    if(TIMER == LQ_TIMERA_0) {
        DL_TimerG_setCCPDirection(timer , 
        DL_TIMER_CC0_OUTPUT | DL_TIMER_CC1_OUTPUT |
        DL_TIMER_CC2_OUTPUT | DL_TIMER_CC3_OUTPUT);
    }
    else  {
        DL_TimerG_setCCPDirection(timer , 
        DL_TIMER_CC0_OUTPUT | DL_TIMER_CC1_OUTPUT);
    }
}

/*************************************************************************
 * @brief       ʹ��PWM����
 * 
 * @param       PWM_PIN         PWM����ö��
 *************************************************************************/
void LQ_TIMER_EnablePWMChannel(LQEnum_PWM_Pin_t PWM_PIN)
{
    IOMUX->SECCFG.PINCM[LQ_PWM_MAP[PWM_PIN][0]] = LQ_PWM_MAP[PWM_PIN][1] | IOMUX_PINCM_PC_CONNECTED;
    
    DL_GPIO_enableOutput(LQ_GPIO_Regs[LQ_GPIO_MAP[LQ_PWM_MAP[PWM_PIN][0]][0]], LQ_GPIO_MAP[LQ_PWM_MAP[PWM_PIN][0]][1]);
    
    DL_Timer_setCaptureCompareOutCtl(LQ_TIMER_Regs[LQ_PWM_MAP[PWM_PIN][3]], 
        DL_TIMER_CC_OCTL_INIT_VAL_LOW,
		DL_TIMER_CC_OCTL_INV_OUT_DISABLED, 
        DL_TIMER_CC_OCTL_SRC_FUNCVAL,
	    LQ_PWM_MAP[PWM_PIN][2]);

    DL_Timer_setCaptCompUpdateMethod(LQ_TIMER_Regs[LQ_PWM_MAP[PWM_PIN][3]], 
        DL_TIMER_CC_UPDATE_METHOD_IMMEDIATE, 
        LQ_PWM_MAP[PWM_PIN][2]);
}

/*************************************************************************
 * @brief       ���� PWM ���
 * 
 * @param       TIMER           ��ʱ��ö��
 * 
 * @example     LQ_TIMER_Start(LQ_TIMERA_0);
 *************************************************************************/
void LQ_TIMER_PWM_Start(LQEnum_Timer_t TIMER)
{
    LQ_TIMER_Regs[TIMER]->COUNTERREGS.CTRCTL |= (GPTIMER_CTRCTL_EN_ENABLED);
}

/*************************************************************************
 * @brief       ֹͣ PWM ���
 * 
 * @param       TIMER           ��ʱ��ö��
 * 
 * @example     LQ_TIMER_Start(LQ_TIMERA_0);
 *************************************************************************/
void LQ_TIMER_PWM_Stop(LQEnum_Timer_t TIMER)
{
    LQ_TIMER_Regs[TIMER]->COUNTERREGS.CTRCTL &= ~(GPTIMER_CTRCTL_EN_ENABLED);
}

/*************************************************************************
 * @brief       ����PWM����Ƚ�ֵ��ռ�ձȣ�
 * 
 * @param       PWM_PIN         PWM����ö��
 * @param       Value           PWMֵ
 *************************************************************************/
void LQ_TIMER_PWMSetCaptureCompare(LQEnum_PWM_Pin_t PWM_PIN, uint32_t Value)
{
    volatile uint32_t *pReg;

    pReg = &LQ_TIMER_Regs[LQ_PWM_MAP[PWM_PIN][3]]->COUNTERREGS.CC_01[0];
    pReg += (uint32_t) LQ_PWM_MAP[PWM_PIN][2];

    *pReg = (Value);
}

/*************************************************************************
 * @name     LQ_PWM_CalcOptimal
 *
 * @brief    ����Ŀ��Ƶ�ʼ�������PWM����(��Ƶ�ȡ�Ԥ��Ƶ������װ��ֵ)
 * @param    ch          : ��ʱ��ͨ��ö�٣���������ʱ��Դ
 * @param    target_freq : Ŀ��PWMƵ��
 * @return   PWM_ConfigTypeDef : ����PWM���ò���
 *
 * @note     �Զ�ѡ��������ϣ�ʹ��װ��ֵPeriod���PWM�����ϸ
 *************************************************************************/
PWM_ConfigTypeDef LQ_PWM_CalcOptimal(LQEnum_Timer_t ch, uint32_t target_freq)
{
    PWM_ConfigTypeDef best = {0};
    uint32_t max_period = 65535U;
    uint32_t best_period = 0;
    uint32_t pwm_system_clk = 0;
    if (ch == LQ_TIMERG_0 || ch == LQ_TIMERG_6)
        pwm_system_clk = CPUCLK_FREQ / 2;
    else
        pwm_system_clk= CPUCLK_FREQ;

    // �������з�Ƶ��ϣ��� Period ���ĺϷ�����
    for (uint8_t dr = 1; dr <= 8; dr++) {
        // �� int ������ uint8_t�����ױ��������ѭ��������
        for (int psc = 0; psc <= 255; psc++) {
            uint32_t denominator = (uint32_t)dr * (psc + 1) * target_freq;
            uint32_t period = pwm_system_clk / denominator;
            // �������� period <= ���ֵ����Խ��Խ��
            if (period >= 1 && period <= max_period) {
                if (period > best_period) {
                    best_period = period;
                    best.DivideRatio = dr;
                    best.Prescaler = (uint8_t)psc;
                    best.Period = period;
                }
            }
        }
    }
    return best;
}
