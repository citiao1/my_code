$root = $PSScriptRoot
$files = Get-ChildItem -Path $root -Filter "*.h" -Recurse
$bad = @()
foreach ($f in $files) {
    $line = (Get-Content $f.FullName -TotalCount 1 -Encoding UTF8 -ErrorAction SilentlyContinue)
    if ($line -and $line.StartsWith("-#")) {
        $bad += "$($f.FullName) :: $line"
    }
}
$files2 = Get-ChildItem -Path $root -Filter "*.c" -Recurse
foreach ($f in $files2) {
    $line = (Get-Content $f.FullName -TotalCount 1 -Encoding UTF8 -ErrorAction SilentlyContinue)
    if ($line -and $line.StartsWith("-#")) {
        $bad += "$($f.FullName) :: $line"
    }
}
if ($bad.Count -eq 0) {
    Write-Host "No files start with '-#'"
} else {
    Write-Host "BAD files:"
    $bad | ForEach-Object { Write-Host $_ }
}
