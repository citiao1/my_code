#ifndef __INCLUDE_H_
#define __INCLUDE_H_


/*  ϵͳͷ�ļ�  */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "ti_msp_dl_config.h"


/*  �û�ͷ�ļ�  */
#include "LQ_gpio.h"
#include "LQ_key.h"
#include "LQ_oled.h"
#include "LQ_oledfont.h"
#include "LQ_encoder.h"
#include "LQ_motor.h"
#include "LQ_servo.h"
#include "LQ_usart.h"
#include "LQ_lsm6dsr.h"
#include "LQ_tracking.h"


/*  �û�ͷ�ļ�  */




/*  ��������  */
void delay_us(unsigned long __us);
void delay_ms(unsigned long ms);

#endif
