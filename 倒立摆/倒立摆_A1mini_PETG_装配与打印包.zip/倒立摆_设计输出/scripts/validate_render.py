import sys,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'.cad_runtime'))
import cadquery as cq
import vtk
OUT=ROOT/'设计输出'
manifest={i['name']:i for i in json.loads((OUT/'检查记录'/'零件清单.json').read_text(encoding='utf-8'))}
items=json.loads((OUT/'检查记录'/'装配实例.json').read_text(encoding='utf-8'))
shapes={n:cq.importers.importStep(str(OUT/'STEP零件'/(n+'.step'))).val() for n in manifest}
inst=[(i,shapes[i['name']].translate(tuple(i['translation']))) for i in items]
def overlapping(a,b):
    p=a.BoundingBox();q=b.BoundingBox()
    return not any([p.xmax<=q.xmin+.001,q.xmax<=p.xmin+.001,p.ymax<=q.ymin+.001,q.ymax<=p.ymin+.001,p.zmax<=q.zmin+.001,q.zmax<=p.zmin+.001])
rod=shapes['P13_Pendulum_135'];collisions=[]
for angle in range(0,360,5):
    moved=rod.rotate((156,0,176),(157,0,176),angle)
    for i,s in inst:
        if i['group']=='pendulum':continue
        if overlapping(moved,s):
            v=moved.intersect(s).Volume()
            if v>.02:collisions.append([angle,i['name'],round(v,5)])
result={'static_interferences':json.loads((OUT/'检查记录'/'干涉检查.json').read_text(encoding='utf-8')),'pendulum_sweep_degrees':list(range(0,360,5)),'pendulum_collisions':collisions,'limits':'Exact BRep intersections at 5-degree samples; rods/fasteners not all modeled; no load/dynamic validation.'}
print(json.dumps(result),flush=True)
(OUT/'检查记录'/'运动检查.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
def actor(s,color):
    vs,ts=s.tessellate(.12,.2);pts=vtk.vtkPoints();cells=vtk.vtkCellArray()
    for p in vs:pts.InsertNextPoint(p.x,p.y,p.z)
    for t in ts:
        tri=vtk.vtkTriangle()
        for k in range(3):tri.GetPointIds().SetId(k,t[k])
        cells.InsertNextCell(tri)
    poly=vtk.vtkPolyData();poly.SetPoints(pts);poly.SetPolys(cells)
    norms=vtk.vtkPolyDataNormals();norms.SetInputData(poly);norms.SetFeatureAngle(45)
    mapper=vtk.vtkPolyDataMapper();mapper.SetInputConnection(norms.GetOutputPort())
    a=vtk.vtkActor();a.SetMapper(mapper);a.GetProperty().SetColor(*color);a.GetProperty().SetSpecular(.3);a.GetProperty().SetSpecularPower(35)
    return a
def render(filename,down=False,exploded=False,view='iso'):
    renderer=vtk.vtkRenderer();renderer.SetBackground(.96,.97,.985)
    for i,s in inst:
        g=i['group'];name=i['name'];p=manifest[name]
        color=(.10,.39,.62) if p['printed'] else (.58,.61,.65)
        if g=='pendulum':color=(.98,.48,.08)
        if name=='E01_MG513_Original':color=(.32,.34,.37)
        if name=='E02_WDD35D4_Original':color=(.6,.63,.66)
        if down and g=='pendulum':s=s.rotate((156,0,176),(157,0,176),180)
        if exploded:
            if name.startswith('P01'):offset=(0,0,-50)
            elif name.startswith(('P02','E01','P03')):offset=(0,0,-20)
            elif g=='rotor':offset=(0,0,80)
            elif g=='pendulum':offset=(65,0,80)
            else:offset=(0,0,20)
            s=s.translate(offset)
        renderer.AddActor(actor(s,color))
    cam=renderer.GetActiveCamera();cam.SetViewUp(0,0,1);cam.ParallelProjectionOn()
    if view=='side':cam.SetPosition(600,500,300);cam.SetFocalPoint(60,0,130)
    else:cam.SetPosition(530,-650,430);cam.SetFocalPoint(60,0,145)
    renderer.ResetCamera();cam.Zoom(1.12)
    win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(1500,1500);win.AddRenderer(renderer);win.SetMultiSamples(4);win.Render()
    capture=vtk.vtkWindowToImageFilter();capture.SetInput(win);capture.Update()
    writer=vtk.vtkPNGWriter();writer.SetFileName(str(OUT/'预览'/filename));writer.SetInputConnection(capture.GetOutputPort());writer.Write();win.Finalize()
render('装配预览.png');render('摆杆下垂.png',down=True);render('分层装配示意.png',exploded=True)
