"""All geometry in millimetres. STEP = installed position; STL/3MF = print position."""
import sys, os, json, math, zipfile, csv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'.cad_runtime'))
import cadquery as cq
import trimesh
OUT=ROOT/'设计输出'
for d in ['STEP零件','STL打印','SolidWorks','预览','检查记录']:(OUT/d).mkdir(exist_ok=True)
parts=[]
def box(x,y,z,dx,dy,dz):return cq.Workplane('XY').box(dx,dy,dz,centered=False).translate((x,y,z)).val()
def cyl(r,h,p=(0,0,0),axis=(0,0,1)):return cq.Solid.makeCylinder(r,h,cq.Vector(*p),cq.Vector(*axis))
def ring(ro,ri,h,p=(0,0,0),axis=(0,0,1)):return cyl(ro,h,p,axis).cut(cyl(ri,h,p,axis))
def holes(s,points,r,h,z):
    for x,y in points:s=s.cut(cyl(r,h,(x,y,z)))
    return s
def endpoint(s):return s.rotate((0,0,0),(0,0,1),90).translate((156,0,176))
def part(name,s,group='stationary',printed=True,orient=None,qty=1,note=''):
    s=s.clean(); assert s.isValid(),name
    assert len(s.Solids())==1,(name,len(s.Solids()))
    cq.exporters.export(s,str(OUT/'STEP零件'/f'{name}.step'))
    item={'name':name,'group':group,'printed':printed,'quantity':qty,'note':note,'volume_mm3':s.Volume()}
    if printed:
        p=s if orient is None else orient(s)
        b=p.BoundingBox();p=p.translate((-b.xmin,-b.ymin,-b.zmin))
        b=p.BoundingBox();dims=[b.xlen,b.ylen,b.zlen]
        assert max(dims)<177,(name,dims)
        cq.exporters.export(p,str(OUT/'STL打印'/f'{name}.stl'),tolerance=.025,angularTolerance=.12)
        m=trimesh.load_mesh(str(OUT/'STL打印'/f'{name}.stl'))
        assert m.is_watertight,(name,'not watertight')
        assert m.is_winding_consistent,(name,'inconsistent normals')
        item.update(print_bbox_mm=[round(v,3) for v in dims],mesh_watertight=True,triangles=len(m.faces))
        # One generic 3MF per part. Unit and object name are explicit; no printer profile/G-code.
        verts=''.join(f'<vertex x="{v[0]:.5f}" y="{v[1]:.5f}" z="{v[2]:.5f}"/>' for v in m.vertices)
        faces=''.join(f'<triangle v1="{f[0]}" v2="{f[1]}" v3="{f[2]}"/>' for f in m.faces)
        placement=f' transform="1 0 0 0 1 0 0 0 1 {90-dims[0]/2:.5f} {90-dims[1]/2:.5f} 0"' if name.startswith('P15') else ''
        xml=f'<?xml version="1.0" encoding="UTF-8"?><model unit="millimeter" xml:lang="en-US" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02"><resources><object id="1" name="{name}" type="model"><mesh><vertices>{verts}</vertices><triangles>{faces}</triangles></mesh></object></resources><build><item objectid="1"{placement}/></build></model>'
        with zipfile.ZipFile(OUT/'STL打印'/f'{name}.3mf','w',zipfile.ZIP_DEFLATED) as z:
            z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
            z.writestr('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
            z.writestr('3D/3dmodel.model',xml)
    parts.append((item,s));print(name,flush=True)
    return s
corners=[(x,y) for x in [-25,25] for y in [-25,25]]
base=box(-85,-85,0,170,170,8)
base=holes(base,corners,2.25,10,-1)
base=holes(base,[(x,y) for x in [-74,74] for y in [-74,74]],3.3,10,-1)
# Recess M4 nuts below the base, no support inside a captive blind pocket.
for x,y in corners:base=base.cut(cq.Workplane('XY').polygon(6,8.2).extrude(3.5).translate((x,y,0)).val())
part('P01_Base_170',base,note='底座；4个角孔用于桌面固定，需加配重或夹紧')
column=holes(box(18,18,8,14,14,64),[(25,25)],2.25,66,7)
part('P02_LowerColumn',column,qty=4,note='打印4件；四根M4通长螺杆贯穿整座')
motorplate=holes(box(-32,-32,72,64,64,6),corners,2.25,8,71)
motorplate=motorplate.cut(cyl(6.4,8,(0,0,71)))
motorholes=[(23.05,0),(-.575,13.6399),(-.575,-13.6399)]
motorplate=holes(motorplate,motorholes,1.7,8,71)
part('P03_MG513_Mount',motorplate,note='电机机身中心X=7.3；输出轴X=0；3孔按原STEP提取')
uppercol=holes(box(18,18,78,14,14,16),[(25,25)],2.25,18,77)
part('P04_UpperColumn',uppercol,qty=4)
bridge=holes(box(-32,-32,94,64,64,6),corners,2.25,8,93).cut(cyl(14,8,(0,0,93)))
part('P05_UpperBridge',bridge)
tower=box(-32,-32,100,64,64,5).fuse(box(-22,-22,105,44,44,33))
tower=holes(tower,corners,2.25,7,99)
tower=tower.cut(cyl(13.2,7,(0,0,100))).cut(cyl(9,1,(0,0,107))).cut(cyl(11.1,30,(0,0,108)))
smallcorners=[(x,y) for x in [-17,17] for y in [-17,17]]
tower=holes(tower,smallcorners,1.7,39,99)
for x,y in smallcorners:tower=tower.cut(cq.Workplane('XY').polygon(6,6.5).extrude(7).translate((x,y,100)).val())
part('P06_608_Tower',tower,note='608轴承孔22.20；台阶Z=108，使用12mm外圈隔套')
ret=holes(box(-22,-22,138,44,44,4),smallcorners,1.7,6,137).cut(cyl(8.5,10,(0,0,133)))
ret=ret.fuse(ring(11.0,8.5,4,(0,0,134)))
for x,y in smallcorners:ret=ret.cut(cq.Solid.makeCone(1.7,3.3,1.8,cq.Vector(x,y,140.2),cq.Vector(0,0,1)))
part('P07_608_Retainer',ret,orient=lambda s:s.rotate((0,0,0),(1,0,0),180))
part('P08_608_OuterSpacer',ring(10.9,9,12,(0,0,115)))
# Rotor: horizontal beam, main hub, and an inward sensor platform. Max bed footprint after 45-degree turn.
arm=box(-16,-18,144,165,36,8).fuse(cyl(16,21,(0,0,144)))
arm=arm.fuse(box(74.5,-20,144,74.5,40,8))
arm=arm.cut(cyl(4.15,25,(0,0,142)))
# Radial M3 screw + open nut pocket fixes hub onto steel shaft, never plastic threads.
arm=arm.cut(cyl(1.7,18,(0,0,155),(1,0,0))).cut(box(8.5,-3,151.8,2.7,6,14.2))
for gx in [133,145]:
    for gy in [-13,13]:arm=arm.cut(cyl(1.7,10,(gx,gy,143)))
for gx in [78.5,94.5]:
    for gy in [-14,14]:arm=arm.cut(cyl(1.7,10,(gx,gy,143)))
part('P09_RotaryArm_156',arm,'rotor',orient=lambda s:s.rotate((0,0,0),(0,0,1),45),note='主轴至摆轴156mm；STL已斜放，可装入A1mini')
# Endpoint is generated in an auxiliary frame then rotated 90 degrees: shaft is RADIAL (global X).
f=box(-18,7,-24,36,21,41)
f=f.cut(cyl(3.9,23,(0,6,0),(0,1,0)))
for y in [7,23]:f=f.cut(cyl(8.1,5,(0,y,0),(0,1,0)))
for y in [11,23]:
    f=holes(f,[(-13,y),(13,y)],1.7,25,-25)
    for x in [-13,13]:f=f.cut(cyl(3.0,25,(x,y,-7)))
for zz in [-12,12]:
    f=f.cut(cyl(1.7,23,(0,6,zz),(0,1,0)))
    # Two short cap screws each meet their own captive nut in the central core.
    for ny in [13,19.5]:f=f.cut(box(-3.2,ny,zz-3.1,21.3,3,6.2))
part('P10_Dual625_Pedestal',endpoint(f),'rotor',orient=lambda s:s.rotate((0,0,0),(0,1,0),90),note='单侧双轴承，避开摆杆整周扫掠面；轴承间隔11mm')
for cy,label in [(5,'Outer'),(28,'Inner')]:
    cap=box(-18,cy,-17,36,2,34).cut(cyl(4.1,4,(0,cy-1,0),(0,1,0)))
    for zz in [-12,12]:cap=cap.cut(cyl(1.7,4,(0,cy-1,zz),(0,1,0)))
    part('P11_BearingCap_'+label,endpoint(cap),'rotor',orient=lambda s:s.rotate((0,0,0),(0,1,0),90))
# Sensor seat: foot at the arm plane; original pilot 20mm and all four original holes are preserved.
br=box(-20,57.5,-24,40,24,4).fuse(box(-20,65.5,-24,40,4,47))
# Gussets outside the sensor flange, under its lower envelope.
for xx in [-20,16]:
    br=br.fuse(box(xx,61.5,-24,4,4,18))
br=br.cut(cyl(10.25,6,(0,64.5,0),(0,1,0)))
sensorholes=[(15,0),(-15,0),(7.5,12.9904),(7.5,-12.9904)]
for x,v in sensorholes:br=br.cut(cyl(1.4,6,(x,64.5,-v),(0,1,0)))
br=holes(br,[(x,y) for x in [-14,14] for y in [61.5,77.5]],1.7,6,-25)
# Foot bolt positions must align with the four platform holes. Move front row to y=42 within the flange support.
part('P12_WDD35D4_Seat',endpoint(br),'rotor',orient=lambda s:s.rotate((0,0,0),(1,0,0),90),note='M2.5安装孔；20.5mm前凸台避空；传感器后方预留出线')
# Pendulum: pivot-to-tip centre135mm, flat-printed, shaft carried by two 625 bearings.
rod=box(-6,-4,0,12,8,135).fuse(cyl(11,8,(0,-4,0),(0,1,0))).fuse(cyl(9,8,(0,-4,135),(0,1,0)))
rod=rod.cut(cyl(2.6,10,(0,-5,0),(0,1,0)))
rod=rod.cut(cyl(1.7,14,(0,0,0),(1,0,0))).cut(box(6.5,-4.1,-3,2.6,7.3,6))
for h in [45,90,125,135]:rod=rod.cut(cyl(1.7,10,(0,-5,h),(0,1,0)))
part('P13_Pendulum_135',endpoint(rod),'pendulum',orient=lambda s:s.rotate((0,0,0),(0,1,0),90),note='135mm为转轴至末端孔中心；M3配重孔；摆杆轴孔5.2')
# Fit coupon is separate from assembly: test before long prints.
coupon=box(0,0,0,74,28,6)
for x,d in [(10,5.1),(26,6.2),(45,8.2),(62,16.2)]:coupon=coupon.cut(cyl(d/2,8,(x,14,-1)))
part('P14_FitCoupon',coupon,'coupon',note='先打印校验：5.1/6.2/8.2/16.2mm四孔')
# Original equipment, transformed without changing or remodeling it.
motorfile=next((ROOT/'3D').rglob('*MG513*.stp'))
sensorfile=next((ROOT/'3D').rglob('*WDD35D4*.stp'))
motor=cq.importers.importStep(str(motorfile)).val().rotate((0,0,0),(1,0,0),90).translate((7.3,0,72))
part('E01_MG513_Original',motor,printed=False,note='用户原始STEP；轴径6；输出轴偏置7.3')
sensor=cq.importers.importStep(str(sensorfile)).val().rotate((0,0,0),(1,0,0),-90).translate((0,69.5,0))
part('E02_WDD35D4_Original',endpoint(sensor),'rotor',False,note='用户原始STEP；轴径6；法兰外径36.5')
part('H01_Shaft8x68',cyl(4,68,(0,0,93)),'rotor',False,note='8mm光轴，长68mm；夹紧位可磨平')
part('H02_Shaft5x54',endpoint(cyl(2.5,54,(0,-5.5,0),(0,1,0))),'pendulum',False,note='5mm光轴长54mm；夹紧位可磨平')
for z,label in [(108,'Lower'),(127,'Upper')]:part('H03_608_'+label,ring(11,4,7,(0,0,z)),printed=False)
for y,label in [(7,'Outer'),(23,'Inner')]:part('H04_625_'+label,endpoint(ring(8,2.5,5,(0,y,0),(0,1,0))),'rotor',False)
# Coupling envelopes include bores; obtain commercial clamp couplings in these envelopes.
coupling= cyl(10,25,(0,0,80)).cut(cyl(3,12.5,(0,0,80))).cut(cyl(4,12.5,(0,0,92.5)))
part('H05_Coupling_6to8_D20L25',coupling,'rotor',False,note='采购夹紧联轴器6-8，外径不超过20、长度25')
cp=cyl(9.5,25,(0,37,0),(0,1,0)).cut(cyl(2.5,12.5,(0,37,0),(0,1,0))).cut(cyl(3,12.5,(0,49.5,0),(0,1,0)))
part('H06_Coupling_5to6_D19L25',endpoint(cp),'rotor',False,note='采购柔性夹紧联轴器5-6，外径不超过19、长25；示意包络非加工图')
part('H07_Collar8_D16H8',ring(8,4,8,(0,0,134)),'rotor',False,note='8mm轴用锁紧环，外径16、高8；包络模型')
# Two inner-race spacers avoid the rod and coupling rubbing the bearing seals.
for y,h,label in [(4,3,'Outer'),(28,2.5,'Inner')]:part('P15_625_InnerSpacer_'+label,endpoint(ring(3.8,2.65,h,(0,y,0),(0,1,0))),'pendulum',orient=lambda s:s.rotate((0,0,0),(0,1,0),90))
part('H08_Collar5_D10H6',endpoint(ring(5,2.5,6,(0,30.5,0),(0,1,0))),'pendulum',False,note='5mm轴用锁紧环，外径10、高6；包络模型')
# Duplicate identical column geometry in the assembly (the STL needs four prints).
instances=[]
for item,s in parts:
    if item['group']=='coupon':continue
    if item['quantity']==4:
        for x,y in corners:instances.append((item,s.translate((x-25,y-25,0)),[x-25,y-25,0]))
    else:instances.append((item,s,[0,0,0]))
ass=cq.Assembly(name='Furuta_156_135_A1mini_PETG')
for i,(item,s,t) in enumerate(instances):
    color=(.1,.4,.65) if item['printed'] else (.65,.68,.72)
    if item['group']=='pendulum':color=(.95,.5,.08)
    ass.add(s,name=f'{item["name"]}_{i}',color=cq.Color(*color))
ass.export(str(OUT/'倒立摆_完整装配.step'))
manifest=[item for item,s in parts]
(OUT/'检查记录'/'零件清单.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'检查记录'/'装配实例.json').write_text(json.dumps([{'name':i['name'],'group':i['group'],'translation':t} for i,s,t in instances],ensure_ascii=False,indent=2),encoding='utf-8')
# Exact solid interference audit. Boundary contact is permitted; material overlap is reported.
overlaps=[]
for a in range(len(instances)):
    ia,sa,_=instances[a];ba=sa.BoundingBox()
    for ib,sb,_ in instances[a+1:]:
        bb=sb.BoundingBox()
        if any([ba.xmax<=bb.xmin+.001,bb.xmax<=ba.xmin+.001,ba.ymax<=bb.ymin+.001,bb.ymax<=ba.ymin+.001,ba.zmax<=bb.zmin+.001,bb.zmax<=ba.zmin+.001]):continue
        v=sa.intersect(sb).Volume()
        if v>.02:overlaps.append({'a':ia['name'],'b':ib['name'],'overlap_mm3':round(v,5)})
(OUT/'检查记录'/'干涉检查.json').write_text(json.dumps(overlaps,ensure_ascii=False,indent=2),encoding='utf-8')
print('OVERLAPS',json.dumps(overlaps,ensure_ascii=False),flush=True)
