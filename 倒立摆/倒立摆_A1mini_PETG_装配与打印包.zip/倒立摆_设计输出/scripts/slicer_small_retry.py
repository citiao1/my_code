import json,subprocess,zipfile
from pathlib import Path
OUT=Path(__file__).resolve().parents[1];cfg=OUT/'检查记录'/'切片验证'
p=json.loads((cfg/'process.json').read_text(encoding='utf-8'))
p.update(enable_support='0',wall_loops='3',brim_type='outer_only',brim_width='3')
(cfg/'process_small.json').write_text(json.dumps(p),encoding='utf-8')
records=json.loads((OUT/'检查记录'/'Bambu切片验证.json').read_text(encoding='utf-8'))
for name in ['P15_625_InnerSpacer_Outer','P15_625_InnerSpacer_Inner']:
    source=OUT/'STL打印'/(name+'.3mf');target=cfg/(name+'_centered.3mf')
    with zipfile.ZipFile(source) as zi,zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as zo:
        for n in zi.namelist():
            data=zi.read(n)
            if n.endswith('.model'):data=data.replace(b'<item objectid="1"/>',b'<item objectid="1" transform="1 0 0 0 1 0 0 0 1 86.2 86.2 0"/>')
            zo.writestr(n,data)
    work=cfg/(name+'_retry');work.mkdir(exist_ok=True)
    cmd=[r'D:\Bambu Studio\bambu-studio.exe','--debug','4','--load-settings',str(cfg/'machine.json')+';'+str(cfg/'process_small.json'),'--load-filaments',str(cfg/'filament.json'),'--arrange','0','--ensure-on-bed','--slice','0','--outputdir',str(work),str(target)]
    with (cfg/(name+'_retry.log')).open('wb') as log:
        try:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=25);code=r.returncode
        except subprocess.TimeoutExpired:code='timeout'
    print(name,code,flush=True)
    if code==0:
        for row in records:
            if row['part']==name:row.update(returncode=0,profile='A1 mini 0.4 / Generic PETG / 0.20mm / 3 walls / 3mm brim',supports='disabled',validation='Centered single-part 3MF; auto-arrange disabled')
(OUT/'检查记录'/'Bambu切片验证.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
