"""Add an editable cut to the existing native motor deck; preserve assembly positions."""
exec((__import__('pathlib').Path(__file__).parent/'sw_probe.py').read_text(encoding='utf-8'))
import json,math
OUT=Path(__file__).resolve().parents[1];SW=OUT/'SolidWorks'
name='V2_P03_MotorDeck.SLDPRT';doc=None
for od in sw.GetDocuments() or []:
    d=mod.IModelDoc2(od._oleobj_)
    if d.GetTitle().lower()==name.lower():doc=d
if doc is None:doc,err,warn=sw.OpenDoc6(str(SW/name),1,1,'',0,0)
assert doc is not None
sw.ActivateDoc3(doc.GetTitle(),False,0,0)
pd=mod.IPartDoc(doc._oleobj_)
def volume():return mod.IMassProperty(doc.Extension.CreateMassProperty()._oleobj_).Volume*1e9
before=volume();found=None;plane=None;f=doc.FirstFeature()
while f:
    f=mod.IFeature(f._oleobj_)
    if f.GetTypeName2()=='RefPlane' and plane is None:plane=f
    if f.Name=='AngleSensor_WirePassage_18x8':found=f
    f=f.GetNextFeature()
if found is None:
    sm=mod.ISketchManager(doc.SketchManager._oleobj_)
    if sm.ActiveSketch is None:
        doc.ClearSelection2(True);assert plane.Select2(False,0)
        sm.InsertSketch(True);sm.AddToDB=True
        # Capsule: centres are 10mm apart, radius4mm, overall18x8mm.
        assert sm.CreateLine(-.027,.026,0.,-.017,.026,0.) is not None
        assert sm.CreateArc(-.017,.022,0.,-.017,.018,0.,-.017,.026,0.,1) is not None
        assert sm.CreateLine(-.017,.018,0.,-.027,.018,0.) is not None
        assert sm.CreateArc(-.027,.022,0.,-.027,.026,0.,-.027,.018,0.,1) is not None
        sm.AddToDB=False
    assert len(mod.ISketch(sm.ActiveSketch._oleobj_).GetSketchSegments())==4
    sm.InsertSketch(True)
    sf=None;ff=doc.FirstFeature()
    while ff:
        ff=mod.IFeature(ff._oleobj_)
        if ff.GetTypeName2()=='ProfileFeature':sf=ff
        ff=ff.GetNextFeature()
    assert sf is not None
    sf.Name='WirePassage_18x8_Sketch'
    doc.ClearSelection2(True);assert sf.Select2(False,0)
    fm=mod.IFeatureManager(doc.FeatureManager._oleobj_)
    found=fm.FeatureCut3(False,False,False,1,1,.2,.2,False,False,False,False,0.,0.,False,False,False,False,False,True,True,False,False,False,0,0.,False)
    assert found is not None,'Cut feature failed'
    found=mod.IFeature(found._oleobj_);found.Name='AngleSensor_WirePassage_18x8'
doc.ClearSelection2(True);doc.ForceRebuild3(False)
after=volume();expected=(10*8+math.pi*4**2)*3
assert len(pd.GetBodies2(0,False))==1
assert found.GetErrorCode2()[0]==0
manifest=json.loads((OUT/'检查记录'/'零件清单.json').read_text(encoding='utf-8'))
target=next(x['volume_mm3'] for x in manifest if x['name']=='V2_P03_MotorDeck')
assert abs(after-target)<.03,(before,after,target)
r=doc.Save3(1,0,0);assert r[0] and r[1]==0,r
report={'native_feature':found.Name,'slot_mm':[18,8],'centre_mm':[-22,22],'z_extent_mm':[94,97],'before_volume_mm3':before,'after_volume_mm3':after,'source_step_volume_mm3':target,'expected_removed_mm3':expected,'save':r,'feature_error':found.GetErrorCode2()}
saved=[];top=None
for od in sw.GetDocuments() or []:
    d=mod.IModelDoc2(od._oleobj_)
    if d.GetType()==2 and '设计输出_V2_短螺丝直连' in d.GetPathName():
        d.ForceRebuild3(False);rr=d.Save3(1,0,0);assert rr[0] and rr[1]==0,(d.GetTitle(),rr);saved.append(d.GetTitle())
        if d.GetTitle().lower()=='v2_furuta_directdrive_297.sldasm':top=d
report['assemblies_saved']=saved
if top:
    sw.ActivateDoc3(top.GetTitle(),False,0,0);top.GraphicsRedraw2()
    top.SaveBMP(str(OUT/'预览'/'SolidWorks实际装配.bmp'),1400,1100)
(OUT/'检查记录'/'穿线孔SolidWorks验证.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False),flush=True)
