import json,zipfile,hashlib
from pathlib import Path
OUT=Path(__file__).resolve().parents[1];ROOT=OUT.parent
m=json.loads((OUT/'检查记录'/'零件清单.json').read_text(encoding='utf-8'))
s=json.loads((OUT/'检查记录'/'Bambu切片验证.json').read_text(encoding='utf-8'))
assert len(s)==9 and all(x['returncode']==0 for x in s)
assert json.loads((OUT/'检查记录'/'干涉检查.json').read_text(encoding='utf-8'))==[]
assert json.loads((OUT/'检查记录'/'运动检查.json').read_text(encoding='utf-8'))['pendulum_collisions']==[]
v=json.loads((OUT/'检查记录'/'SolidWorks最终验证.json').read_text(encoding='utf-8'))
assert len(v['mates'])==4 and all(x['feature_error'][0]==0 for x in v['mates'])
files=[]
for row in m:
    n=row['name'];files +=[OUT/'STEP零件'/(n+'.step'),OUT/'SolidWorks'/(n+'.SLDPRT')]
    if row['printed']:files +=[OUT/'STL打印'/(n+'.stl'),OUT/'STL打印'/(n+'.3mf')]
files +=[OUT/'SolidWorks'/(n+'.SLDASM') for n in ['V2_A01_Stationary','V2_A02_Rotor','V2_A03_Pendulum','V2_Furuta_DirectDrive_297']]
files +=[OUT/'V2_倒立摆_完整装配.step',OUT/'打印与装配说明_V2.md']
files +=list((OUT/'预览').glob('*.png'))
if (OUT/'预览'/'SolidWorks实际装配.bmp').exists():files.append(OUT/'预览'/'SolidWorks实际装配.bmp')
for n in ['零件清单.json','装配实例.json','干涉检查.json','运动检查.json','Bambu切片验证.json','SolidWorks最终验证.json','穿线孔SolidWorks验证.json']:
    files.append(OUT/'检查记录'/n)
for n in ['build_v2.py','build_solidworks.py','validate_render.py','sw_probe.py','final_verify_sw.py','slicer_check.py','package_outputs.py','add_wire_slot_sw.py']:
    files.append(OUT/'scripts'/n)
assert all(p.exists() for p in files)
rows=[{'file':p.relative_to(OUT).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
p=OUT/'检查记录'/'交付文件校验.json';p.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8');files.append(p)
path=ROOT/'倒立摆_V2_短螺丝直连_A1mini_PETG.zip'
with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,arcname='倒立摆_V2/'+p.relative_to(OUT).as_posix())
with zipfile.ZipFile(path) as z:assert z.testzip() is None
print(path,len(files),path.stat().st_size)
